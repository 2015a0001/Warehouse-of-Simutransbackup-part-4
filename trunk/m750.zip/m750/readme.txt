Thank you for downloading set of Meitetsu mo750 series.

-contents-
-vehicle.koa_Meitetsu_m760.pak		:addon
-vehicle.koa_Meitetsu_m760_green.pak	:addon
-vehicle.koa_Meitetsu_m750.pak		:addon
-vehicle.koa_Meitetsu_m750_green.pak	:addon
-vehicle.koa_Meitetsu_m510.pak		:addon
-vehicle.koa_Meitetsu_m510_express.pak	:addon
-vehicle.koa_Meitetsu_m520.pak		:addon
-vehicle.koa_Meitetsu_m520_express.pak	:addon
-vehicle.koa_Kitaena_m560.pak		:addon
-vehicle.koa_Meitetsu_m401.pak		:addon
-vehicle.koa_Meitetsu_m401_p.pak	:addon
-vehicle.koa_Meitetsu_m180.pak		:addon
-vehicle.koa_Meitetsu_m130.pak		:addon
-m750.png				:source(image)
-m510.png				:source(image)
-m180.png				:source(image)
-m130.png				:source(image)
-m750.dat				:source(setting)
-ja.tab				:document that translated train name into Japanese
-en.tab				:document that translated train name into English
-���ł�.txt				:document that translated "readme.txt" into Japanese
-readme.txt				:this

-how to use-
 Put pak files in pak128.japan folder.
Use attached dat & png files if you remodel addons.
There are ja.tab & en.tab in text folder under pak128.japan folder.
Use these that add in the same tab files.
These series in train depot.
available period is from 1926.


[Caution!] if you downloaded by 02/25/2015.
You can't connect 520 series and 520 series because I change constraint of 520 series.
Remove formation of 520 series only from your map when you download again.

-right-
 This copyright is owned by koa. 
You may remodel source file. And distribute there when you use there with simutrans and
other softwares(Commerce is available).

-history-
02/24/2013 release
03/03/2013 m520 were added
03/04/2013 m510 were added
03/17/2013 m750 were corrected tail lamps
04/29/2014 m510 & m520 were remodeled
02/26/2015 m130 & m180 & m400 & m760 were added. and All remodeled
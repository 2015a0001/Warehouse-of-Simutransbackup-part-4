#!/bin/bash
set -e
for i; do
    case $i in
        *=*)
            a=("${a[@]}" -e "s|\\\${${i%%=*}}|${i#*=}|g");;
        *)
            a=("${a[@]}" $i);;
    esac
done
sed "${a[@]}"

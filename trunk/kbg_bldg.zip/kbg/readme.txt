Thank you for downloading city-building set.

-contents-
 building.kbg.pak                        :pak file
 source                                     :source of city-building set
 readme.txt                               :here
 ���ł�.txt                             :document that translated "readme.txt" into Japanese


-how to use-
 Put pak file in pak128 folder or pak128.japan folder.

-about copyright-
 Koa who is the producer has the copyright.
You may remodel source file and pak file.
You may distribute remodeled when you use there with simutrans and other softwares.


[Attention!]
 The image of "shuei" might not be correctly displayed by the version of application.
The content of this trouble is that the image for the south north places changes. 
When it is caused, rewrite dat file as follows and re-pak.
It has been confirmed before 99.17.1.


[Before correction]:The under in dat file is a corresponding section. 
Obj=building
Name=shuei
copyright=koa
intro_year=1970
Dims=1,1,4
Type=com
Level=8
BackImage[0][0][0][0][0][0]=shuei.0.0
BackImage[0][0][0][0][0][1]=shuei.0.1
BackImage[1][0][0][0][0][0]=shuei.0.2
BackImage[1][0][0][0][0][1]=shuei.0.3
BackImage[2][0][0][0][0][0]=shuei.0.4
BackImage[2][0][0][0][0][1]=shuei.0.5
BackImage[3][0][0][0][0][0]=shuei.0.6
BackImage[3][0][0][0][0][1]=shuei.0.7

[After correction]:Replace 0 with 2 in the first of BackImage.
Obj=building
Name=shuei
copyright=koa
intro_year=1970
Dims=1,1,4
Type=com
Level=8
BackImage[2][0][0][0][0][0]=shuei.0.0
BackImage[2][0][0][0][0][1]=shuei.0.1
BackImage[1][0][0][0][0][0]=shuei.0.2
BackImage[1][0][0][0][0][1]=shuei.0.3
BackImage[0][0][0][0][0][0]=shuei.0.4
BackImage[0][0][0][0][0][1]=shuei.0.5
BackImage[3][0][0][0][0][0]=shuei.0.6
BackImage[3][0][0][0][0][1]=shuei.0.7

Copyright(c)koa 5/16/2010
03/05/2010 updating
05/16/2010 The parts of image was corrected. And six pak files were added.
02/22/2012 One pak file were added.
09/30/2012 One pak file were added.
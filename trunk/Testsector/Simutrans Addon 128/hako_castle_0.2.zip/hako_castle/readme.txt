hako_castle.pak 0.2 readme.txt
-------
更新記録
0.2
base2、壁、屋根1・2・3を追加。アイコンを追加。
0.1
天守、矢倉、base1。
--

箱積み規格で作るお城です。一部waさんのpak.nipponを4倍したものを下敷きにしていますがもとのクオリティは完全に消失しております。 (;;
ほかの箱積み部品と組み合わせることで城なのか駅なのかわからない建築物もつくれます。(ゲテモノ感はだいぶマシになりました)

問題点:
  ・石垣がない。
  ・上に行くほど小さくなる天守閣が綺麗に作れない。
  ・壁が坂道に対応していない。片面分しかない。
  ・屋根が発光する。

改変・再配布は以下の通りご自由にどうぞ。

The MIT License

Copyright (c) 2014, wa and sazanamitrans

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

-- 2014.08.30 さざなみ海運 (@sazanamitrans)

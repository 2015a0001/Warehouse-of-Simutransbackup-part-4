Boeing787 Dreamliner set
Copyright(c)HIBARI Jan-05-2006
Updated May-01-2006

Thank you for downloading! :-)
This document was translated to the translation site.
I'm sorry when it is hard to read or there is a mistranslation.

This makes a set next-generation medium size passenger plane 787 Dreamliner which Boeing Company is developing aiming at the service in 2008.
The 128th edition and the 64th edition were made in parallel this time also.

As for 787 (development code:7E7), the advanced compound material of carbon fiber reinforced plastics is used for 50% or more of body structure.
The body is lightweight-ized by it and fuel efficiency is improving 20% rather than the airplane of this class by it.
Moreover, the durability of fatigue or corrosion also improved.
A window becomes the good large-sized thing of a view by that, and amenity is improving a humidifier is attached in a cabin for the first time.
Furthermore, the electronic curtain which used LCD is adopted as a window, and it has become an airplane in which the future, such as being equipped fully with Internet connectivity environment, is impressed.

By this set, the following add-ons were made the set.

787-8
In the foundations type of 787, speed is M0.85 (910 km/h) and the number of seats is 223 seats.
It is introduced in 2008.

787-8_Mail
The amount of loading is 1200 bags in the object for mail transportation.
It is introduced in 2008.

787-8_Cargo
The amounts of loading are 200 palettes in the object for consolidated shipment transportation.
It is introduced in 2008.

787-8_JAL
The number of seats is 223 seats on the body of the introductory schedule to JAL (Japan Airlines).
Engine has adopted GEnx of General Electric.
It is introduced in 2008.

787-3_JAL
The number of seats is 296 seats on the short distance type (for domestic flights) body of the introductory schedule to JAL.
Engine has adopted GEnx of General Electric.
It is introduced in 2010.

787-8_ANA
The number of seats is 223 seats on the body of the introductory schedule to ANA (All Nippon Airways).
Engine has adopted Trent1000 of Rolls-Royce.
It is introduced in 2008.

787-3_ANA
The number of seats is 296 seats on the short distance type (for domestic flights) body of the introductory schedule to ANA.
Engine has adopted Trent1000 of Rolls-Royce.
It is introduced in 2010.

The correspondence version is contained in "88_00" folder after Simutrans 88.00.
The correspondence version is contained in "88_04" folder after Simutrans 88.04. 
Please install the thing suitable for the version of Simutrans which you are using.

The correspondence version is set as "sound=4" after Simutrans 88.00.
The correspondence version is set as "sound=comet-jet.wav" after Simutrans 88.04.

Installation only puts each "pak" file into the "pak" folder of Simutrans.
It checked operating satisfactory by Simutrans 88.01, 88.04.2, and 88.09.1.
Operation by other versions is not checked.
It takes care and the add-on is created so that it may operate normally.
It may not operate normally according to factors, such as environment of usage's personal computer or specification change of simutrans, and a problem of a setup, competition with other add-ons.
I cannot guarantee operating normally in all environments.
You need to have responsibility and please judge whether this add-on is used or it does not use :-)

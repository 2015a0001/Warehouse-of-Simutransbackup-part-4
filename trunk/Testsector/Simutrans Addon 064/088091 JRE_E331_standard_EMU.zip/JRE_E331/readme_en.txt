JR East E331 series standard EMU
Copyright(c)HIBARI May-18-2006

Thank you for downloading :-)
This document was translated to the translation website.
I'm sorry when it is hard to read or there is a mistranslation.


*Introduction

E331series EMU is direct-current standard EMU of JR East (East Japan Railway Company) which appeared in 2006.
articulated bogie and DDM (Direct Drived Motor) which were examined by E993 series experimental EMU (ac@train=Advanced Commuter train) which appeared in 2002, AIMS (Advanced Train Information Management System), etc. are adopted.
Since articulated bogie is adopted and the length per 1cars is short rather than the conventional EMU (a length per 1car of 20m), it has length for 10cars of the EMU conventional by 14cars.

Also when it becomes sideways, he is trying for the interval of cars not to open unnaturally in this add-on, in order to express articulated structure.

"length" is set to this add-on.
It is set only to simutrans 88.08 or later that it can use by that.

When a check of operation was carried out by simutrans 88.08.1, and 9 or more carses were connected and having been started, there was a trouble which simutrans ends.
It is not known whether it is the fault of my PC, and whether it is the fault of the simutrans itself.
By that, when the trouble arises, please carry out connecting by 7cars and use it.

In simutrans 88.09.1, even if it connects and starts 14cars, it is checking operating normally :-)

Operation by other versions is not checked.
The trouble which is not expected depending on usage's PC environment may arise.
I cannot have responsibility to the possibility of those troubles.
Please judge with responsibility whether this add-on is used by that.

Installation only puts the pak file of an add-on to use into simutrans/pak/ folder :-)

About distribution of this add-on, as long as it is within the limits of the following conditions, you may carry out freely.
1:Don't carry out distribution for the profit purpose.
2:Change no contents and copyright notation of this zip file.
3:Distribute this whole zip file.
However, when putting in and distributing this add-on to the main simutrans game, on condition that the contents of the pak file are not changed, you may distribute with a pak file simple substance.


*The pak file included in this set

The pak file is divided according to the body color.

01:vehicle.JRE_E331.pak  player color
02:vehicle.JRE_E331p.pak pink


*A list of an add-on

    intro  retire    add-on name   payload weight  speed  power gear  cost   runningcost
01:2006.03 ----.-- JRE Tc_E331       115     24t  120km/h            5700.00     0.22
02:2006.03 ----.-- JRE Tc_E330       115     25t  120km/h            6000.00     0.23
03:2006.03 ----.-- JRE M_E331        107     17t  120km/h 320kw 1.58 7000.00     0.28
04:2006.03 ----.-- JRE T_E331        107     17t  120km/h            2900.00     0.11
05:2006.03 ----.-- JRE T_E331-500    107     17t  120km/h            2900.00     0.11
06:2006.03 ----.-- JRE T_E330        133     22t  120km/h            3200.00     0.12
07:2006.03 ----.-- JRE T_E331-1000   133     20t  120km/h            3100.00     0.12

Connection restriction is carried out so that "JRE T_E331", "JRE T_E 331-500", "JRE T_E330" or, and "JRE Tc_E330" can be connected with the next of "JRE M_E331."
Connection restriction is carried out so that only "JRE M_E331" can be connected with the next of "JRE T_E331."
Connection restriction is carried out so that only "JRE M_E331" can be connected with the next of "JRE T_E 331-500."
Connection restriction is carried out so that only "JRE M_E331" can be connected with the next of "JRE T_E 331-1000."
Connection restriction is carried out so that only "JRE M_E331" can be connected with the next of "JRE Tc_E331."
Connection restriction is carried out so that only "JRE T_E 331-1000" can be connected with the next of "JRE T_E330."
Connection restriction is carried out so that only "JRE Tc_E331" can be connected with the next of "JRE Tc_E330."

"p" is attached to the thing of pink at the end of an add-on name.


*The example of connection

Keiyo Line (pink / 14cars)
[Tc_E331][M_E331][T_E331][M_E331][T_E331-500][M_E331][T_E330][T_E331-1000][M_E331][T_E331][M_E331][T_E331-500][M_E331][Tc_E330]


*Description about organization restrictions

Usually, on the train (new performance train) in Japan, apparatus required in order that an electric vehicle may move is distributed and carried in two or more vehicles.
Therefore, it cannot run only by one car but it is necessary to surely construct a unit by two or more vehicles.

Moreover, only vehicles with a driver's seat are made into the head and the tail end of a train.


*Introduction of japanese.simutrans.com

Most add-ons which Japanese people made are downloadable from http://www.japanese.simutrans.com/.
The add-on which also made HIBARI is first uploaded to japanese.simutrans.com :-)

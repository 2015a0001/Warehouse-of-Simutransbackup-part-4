A small train -- Akiu electric railroad train set
Copyright(c) HIBARI 09/18/2005
04/26/2006 updating (the Pak file was updated)

Thank you for downloading!
This document was translated to the translation site.
I'm sorry when it is hard to read or there is a mistranslation.

*Introduction

The Akiu electric railroad is the railroad of Japan abolished on May 7, 1961.
Having connected between Akiu Hot Spring to Nagamachi of Sendai city of Miyagi Prefecture, it was 16.0km of working kilometers.
Although it was 1067mm gauge of a track, it operated by train comparable as a street car by direct-current 600V electrification.
It seemed to be the calm railroad with a slow operation speed.

Eight kinds of lower vehicles are contained in this train set.
 MOHA1401 type electric coach
 MOHA411 type electric coach
 SAHA401 type coach (it is the accompanying coach of MOHA 1401 type train)
 SAHA402 type coach (it is the accompanying coach of MOHA 411 type train)
 EB101 electric locomotive
 WA501 boxcar (mixed cargo can be loaded)
 TO501 open freight car (the thing of wood loading and the thing of board material loading were prepared)
 TO507 open freight car (bulk cargo cargo can be loaded)

The freight car of MOHA1401 type and MOHA 411 type, and the above can also be pulled. (Since there was a train which run by such organization also in the actual Akiu electric railroad)
Installation only puts each "pak" file into the "pak" folder of Simutrans.
Although it is only the powerless vehicle which is not fit for mass transportation, please use for the production of a local line, connection with the town which wants to develop not much, etc. :-)
Since operation by versions other than Simutrans 86.03.4 is unidentified, please use it by your accountability.

*About a vehicle

MOHA1401 type train
It is the prime type of a car of the Akiu electric railroad on the train of the wooden body manufactured in January, 1925.
Although it was 2 axis cart at the beginning, it is bogie-car-ized behind.
Motorcycle operation and operation which leads an accompanying coach and a freight car are possible.
It is introduced in January, 1925, and it has set up so that it may retire in June, 1946.

MOHA411 type train
It is the train of 2 axis cart of the steel body manufactured in June, 1946.
Although original MOHA410 type was due to be made, since it thought that there was no connector in MOHA410 type and the width of employment in a game narrowed, the MOHA411 type to which the connector is attached was made this time.
Motorcycle operation and operation which leads an accompanying coach and a freight car are possible.
It is introduced in June, 1946, and it has set up so that it may retire in May, 1961.

SAHA401 type coach
It is the coach of 2 axis cart.
Although it is an accompanying coach once, connecting from a train does not have control-related connection only with the power supply for electric lights, and an actual place is a mere coach.
It seems the actual Akiu electric railroad is not only also connected behind a train, but that there was employment of being connected behind an electric locomotive or a freight car.
It has set up so that such employment can also do this "Pak" file.
The body color is united with MOHA1401 type.
It is introduced in January, 1925, and it has set up so that it may retire in June, 1946.

SAHA402 type coach
It is a coach completely of the same shape as SAHA401 type.
The body color is united with MOHA411 type.
It is introduced in June, 1946, and it has set up so that it may retire in May, 1961.

EB101 electric locomotive
It is the small electrical machinery engine of the reverse T type body in 2 axis cart.
Although the Akiu electric railroad was the carriage railroad of 762mm gauge of a track at the beginning, it considered DC600V electrification as change to 1067mm gauge of a track on June 14, 1925, and started electrification business.
This electric locomotive is then introduced.
It is introduced in January, 1925, and it has set up so that it may retire in May, 1961.

WA501 boxcar
It is the boxcar of 2 axis cart.
A consolidated shipment can be loaded.
It is introduced in January, 1925, and it has set up so that it may retire in May, 1961.

TO501 open freight car
It is an open freight car without a side board in 2 axis cart.
Business was started as an Akiu stone orbit at the beginning, and the Akiu electric railroad also made the purpose mining and conveyance of the Akiu stone.
The stone of the shape of a board started in practice was loaded also into this open freight car.
Since there was no board-like stone in cargo at Simutrans, it enabled it to load wood and board material this time.
It is introduced in January, 1925, and it has set up so that it may retire in May, 1961.

TO507 open freight car
It is the open freight car which has a side board with 2 axis cart.
The stone etc. was loaded.
Bulk cargo cargo can be loaded.
It is introduced in January, 1925, and it has set up so that it may retire in May, 1961.

JNR AC electric locomotives and Multisystem locomotives set
Copyright(c)HIBARI Mar-23-2006
Document Corrected to Apr-26-2006

Thank you for downloading :-)
This document was translated to the translation site.
I'm sorry when it is hard to read or there is a mistranslation.


*Introduction

Since it was sad that there was no Japanese-made AC electric locomotives, it made.
All of main AC electric locomotives and Multisystem locomotives of the Japanese National Railways (JNR) were prepared.
Please use by liking :-)

About distribution of this add-on, as long as it is within the limits of the following conditions, you may carry out freely.
1:Don't carry out distribution for the profit purpose.
2:Change no contents and copyright notation of this zip file.
3:Distribute this whole zip file.
However, if Mr. prissi or the development member of simutrans restricts when he puts this add-on into the new version of simutrans, on condition that copyright of a pak file is not changed, you may distribute with a pak file simple substance :-)

Installation only puts each "pak" file into the "pak" folder of Simutrans.
Since operation by versions other than Simutrans 86.03.4 and 88.05.1 is unidentified, please use it by your accountability.


*The list of an add-on included in this set

   [Intro] [Retire][Add-on name][Power supply]           [Weight][Power][Speed] [Gear]
01:1955.07-1966.01 ED44-1       AC20kV(50Hz)             60      1120kw  65km/h 5.81
02:1955.09-1970.03 ED45-1       AC20kV(50Hz)             59.9    1000kw  85km/h 5.69
03:1956.12-1970.03 ED45-11      AC20kV(50Hz)             60      1100kw 100km/h 4.31
04:1957.02-1970.03 ED45-21      AC20kV(50Hz)             60      1640kw 100km/h 5.47
05:1957.06-1975.04 ED70         AC20kV(60Hz)             62.2    1500kw  90km/h 5.69
06:1959.04-1983.07 ED71         AC20kV(50Hz)             67.2    2040kw  95km/h 5.47
07:1961.08-1982.06 ED72         AC20kV(60Hz)             87      1900kw 100km/h 4.44
08:1962.00-1982.09 ED73         AC20kV(60Hz)             67      1900kw 100km/h 4.44
09:1962.11-1982.08 ED74         AC20kV(60Hz)             65      1900kw 100km/h 4.44
10:1963.12-        ED75         AC20kV(50Hz)             67.2    1900kw 100km/h 4.44
11:1965.00-        ED76-0       AC20kV(60Hz)             87      1900kw 100km/h 4.44
12:1968.00-1994.11 ED76-500     AC20kV(50Hz)             90.5    1900kw 100km/h 3.83
13:1967.05-1993.11 ED77         AC20kV(50Hz)             75      1900kW 100km/h 4.44
14:1968.05-2000.07 ED78         AC20kV(50Hz)             81.5    1900kw 100km/h 4.44
15:1986.09-        ED79         AC20kV(50Hz)             68      1900kw 110km/h 3.83
16:1961.12-1987.03 EF70         AC20kV(60Hz)             96      2250kw 100km/h 4.12
17:1968.07-1993.09 EF71         AC20kV(50Hz)            100.8    2700kw 100km/h 4.44

18:1959.08-1975.05 ED46         DC1.5kV/AC20kV(50Hz)     64      1400kw 100km/h 3.95
19:1961.03-1987.03 EF30         DC1.5kV/AC20kV(60Hz)     96      1800kw  85km/h 3.88
20:1962.10-1976.07 ED30         DC1.5kV/AC20kV(60Hz)     64       960kw  75km/h 4.15
21:1962.00-1986.02 EF80         DC1.5kV/AC20kV(50Hz)     96      1950kw 100km/h 3.60
22:1968.12-        EF81-0       DC1.5kV/AC20kV(50/60Hz) 100.8    2550kw 110km/h 3.83
23:1973.08-        EF81-300     DC1.5kV/AC20kV(50/60Hz) 100.8    2550kw 110km/h 3.83

-The information which is unrelated to playing Simutrans as reference information is also indicated.

-Although it makes from an add-on and not being divided, Power supply of ED 75-300 for Kyushu is AC20kV (60Hz).

-intro years and retire years are set as the real manufacture years and real disused car years of locomotive.
 However, there are some which have not set up intro month about what has the unknown manufacture month.

-The weight of an add-on is set as the value which rounded off the above-mentioned numerical value.

-Those introduce only the vehicles in a specific area need to install only the add-on of the following number.
 Hokkaido area 10,12,15
 Tohoku area   01,02,03,04,06,10,13,14,15,17,18,21,22
 Hokuriku area 05,09,16,20,22
 Kyushu area   07,08,09,10,11,19,23


*About locomotives

ED44 1(the name changed to ED90 1 behind.)
AC electrification was carried out Senzan Line for the first time in Japan.
It is the first AC electric locomotive in Japan made for test operation in the Senzan Line.
It is the direct-type engine which operates AC motor with AC current.

ED45 1(the name changed to ED91 1 behind.)
It is AC electric locomotive made at the same period as ED44 1 for test operation in Senzan Line.
It is locomotive of the indirect type which changes AC current into a direct current with a water-cooled ignitron mercury arc rectifier, and operates DC motor.

ED45 11(the name changed to ED91 11 behind.)
The cooling system of an ignitron rectifier is air cooling from time-consuming water cooling with the developed type of ED45.

ED45 21(the name changed to ED91 21 behind.)
The rectifier is an air cooling excitron mercury arc rectifier with the developed type of ED45 for comparison with ignitron.
The output is improving sharply rather than AC electric locomotive till then.

ED70
It is the first mass-produced type AC electric locomotive in Japan made according to AC electrification of Hokuriku Main Line.

ED71
It is AC electric locomotive for large trunks made according to AC electrification of Tohoku Main Line.

ED46(the name changed to ED92 behind.)
They are the perfect AC-DC two ways (an equivalent performance can be taken out also with DC or AC) locomotive world's first by the first Multisystem locomotive in Japan.
It was used for the passenger train of Joban Line after test operation performed in Tohoku Main Line and Joban Line.

EF30
They are the world's first practical use AC-DC two ways locomotive made in order to carry out direct operation of the Moji station of Kammon undersea tunnel of DC electrification, and AC electrification.
In order to prevent rusting by sea water, the body is a product made from stainless steel.

ED72
It is AC electric locomotive made according to AC electrification of Kagoshima Main Line.
Since weight increased by having equipped steam heating equipment, the weight of the wheel unit which uses a middle cart and starts a track is reduced.

EF70
It is the first F class AC electric locomotive made for the weight train lead in the Hokuriku tunnel which is a continuation slope.

ED73
Full length is short from the part ED72 which omitted steam heating equipment with the brother machine of ED72.

EF80
They are the first mass-produced type perfect AC-DC two ways locomotive made for Joban Line.

ED30
They are the AC-DC two ways locomotive of reverse T type made for the AC-DC connection sections of Hokuriku Main Line.

ED74
It is AC electric locomotive made in order to increase locomotive in the case of electrification extension of Hokuriku Main Line.

ED75
302 cars were made from standard type AC electric locomotive made for Tohoku Main Line and Joban Line.
Many variations, such as ED75-300 which became 60Hz correspondence for Kyushu, and ED75-500 made as an experiment for Hokkaido, were made.

ED76
It is AC electric locomotive made in order to increase locomotive according to electrification extension of the Kyushu area.
It puts also into the low route of a weight limit by changing the weight of the wheel unit which starts a track using the middle cart of an air spring type.

ED77(It was made based on ED93.)
It was used in Ban'etsu Saisen by AC electric locomotive made for the branch lines of the AC50Hz section.
The weight of the wheel unit which starts a track using a middle cart so that it may put also into the low route of the weight limit into which ED75 cannot go can be changed now.

ED76-500
It is AC electric locomotive made according to AC electrification of Hokkaido.

ED78(It was made based on ED94.)
It is AC electric locomotive made in order to replace EF64 currently used till then according to AC electrification change of Oou Main Line.
Speed is automatically stopped on a downward slope using AC regeneration brake, and operation has become possible for employment at the Itaya peak.

EF71
It is F form AC electric locomotive made at the same period as ED78 according to AC electrification change of Oou Main Line.
Although fundamental structure is the same as that of ED78, power is 2700kW strongest by AC electric locomotive of Japan.

EF81
It was made in order to carry out direct operation of 50Hz section of AC electrification, 60Hz section of AC electrification, and the DC electrified section.
It is Multisystem locomotive corresponding to three kinds of power supplies for the first time in Japan.

EF81-300
The body is a product made from stainless steel by EF81 made in order to increase locomotive of Kammon undersea tunnel.

ED79
It is AC electric locomotive which converted ED75 in 1986 and was made for the purpose of employment in Seikan Tunnel.

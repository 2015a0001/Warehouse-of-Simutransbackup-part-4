JR East 209 and E501 series commuter EMU set
Copyright(c)HIBARI May-18-2006

Thank you for downloading :-)
This document was translated to the translation website.
I'm sorry when it is hard to read or there is a mistranslation.


*Introduction

209 series are direct-current commuter EMU (Electric Multiple-Unit) of JR East (East Japan Railway Company) which appeared in 1993.
It is EMU by which reduction of weight and cost and rationalization of a life are attained rather than the EMU and others till then.
It became the base of EMU of subsequent JR East.
Compared with 103 series EMU, manufacture cost becomes 70% and power consumption has become 47%.

209-0 series was developed as an inheritor of 103 series EMU of Keihin-Tohoku Line, and appeared in 1993.
6 door car is connected from 1995.

209-3000 series was developed for electrification commencement of business of Hachiko Line, and appeared in 1996.
Except that opening and closing of a door are self-service, it is the same specification as 209-0 series.

209-500 series was developed as an inheritor of 103 series EMU of Chuo-Sobu Line, and appeared in 1998.
Having adopted the body broader than 209-0 series, it became the base of E231 series EMU which appears behind.

209-1000 series was developed for direct operation with Tokyo Metro Chiyoda Line, and appeared in 1999.
It became the base of E231-800 series EMU which appears behind.

E501 series EMU is dual-voltage (1500V DC and 20kV AC) commuter EMU of JR East which appeared in 1995.
It was developed for the purpose of confusion relief of Jo-ban Line based on 209 series.

Installation only puts the pak file of an add-on to use into simutrans/pak/ folder :-)

It checked operating by the following versions.
86.03.4
88.06.3
88.09.1
Operation by other versions is not checked.
The trouble which is not expected depending on usage's PC environment may arise.
I cannot have responsibility to the possibility of those troubles.
Please judge with responsibility whether this add-on is used by that.

About distribution of this add-on, as long as it is within the limits of the following conditions, you may carry out freely.
1: Don't carry out distribution for the profit purpose.
2: Change no contents and copyright notation of this zip file.
3: Distribute this whole zip file.
However, when putting in and distributing this add-on to the main simutrans game, on condition that the contents of a pak file are not changed, you may distribute with a pak file simple substance.


*The pak file included in this set

The pak file is divided according to the body color.
Since vehicles will increase in number too much if all color installations are carried out, it is hard coming to choose vehicles in a garage window.
We recommend you to install only the thing of a color to use.

01:vehicle.JRE_209.pak        209-0 player color
02:vehicle.JRE_209s.pak       209-0 sky blue
03:vehicle.JRE_209ko.pak      209-0 Kanaria yellow and orange
04:vehicle.JRE_209-3000ou.pak 209-3000 orange and uguisu green
05:vehicle.JRE_209-500.pak    209-500 player color
06:vehicle.JRE_209-500k.pak   209-500 Kanaria yellow
07:vehicle.JRE_209-500s.pak   209-500 sky blue
08:vehicle.JRE_209-1000.pak   209-1000 player color
09:vehicle.JRE_209-1000e.pak  209-1000 emerald green
10:vehicle.JRE_E501.pak       E501 player color
11:vehicle.JRE_E501e.pak      E501 emerald green


*A list of an add-on

209-0 series

    intro  retire  add-on name payload weight  speed  power gear  cost   runningcost
01:1993.03 2008.04  JRE Tc209    146     23t  110km/h            5500.00     0.21
02:1993.03 2008.04  JRE Tc208    146     22t  110km/h            5300.00     0.20
03:1993.03 2008.04  JRE M209     156     28t  110km/h 380kw 2.02 8300.00     0.33
04:1993.03 2008.04  JRE M208     156     28t  110km/h 380kw 2.02 8400.00     0.33
05:1993.03 2008.04  JRE T209     156     23t  110km/h            3200.00     0.12
06:1995.04 2008.04  JRE T208     157     24t  110km/h            3300.00     0.13

Connection restriction is carried out so that only "JRE M208" can be connected with the next of "JRE M209."
"s" is attached to the thing of sky blue at the end of an add-on name.
"ko" is attached to the thing of Kanaria yellow and orange at the end of an add-on name.
Six door car (JRE T208) is not one of the things of Kanaria yellow and orange.

209-3000 series

    intro  retire    add-on name    payload weight  speed  power gear  cost   runningcost
01:1996.03 2011.04 JRE Tc209-3000ou   146     23t  110km/h            5500.00     0.21
02:1996.03 2011.04 JRE Tc208-3000ou   146     22t  110km/h            5300.00     0.20
03:1996.03 2011.04 JRE M209-3000ou    156     28t  110km/h 380kw 2.02 8300.00     0.33
04:1996.03 2011.04 JRE M208-3000ou    156     28t  110km/h 380kw 2.02 8400.00     0.33
05:1996.03 2011.04 JRE T209-3000ou    156     23t  110km/h            3150.00     0.12

Connection restriction is carried out so that only "JRE M208-3000ou" can be connected with the next of "JRE M209-3000ou."
There is no thing of player color.

209-500 series

    intro  retire   add-on name  payload weight  speed  power gear  cost   runningcost
01:1998.12 2014.01 JRE Tc209-500   147     26t  120km/h            6200.00     0.24
02:1998.12 2014.01 JRE Tc208-500   147     22t  120km/h            5400.00     0.21
03:1998.12 2014.01 JRE M209-500    162     29t  120km/h 380kw 2.02 8800.00     0.35
04:1998.12 2014.01 JRE M208-500    162     29t  120km/h 380kw 2.02 8600.00     0.34
05:1998.12 2014.01 JRE T209-500    162     22t  120km/h            3300.00     0.13

Connection restriction is carried out so that only "JRE M 208-500" can be connected with the next of "JRE M 209-500."
"k" is attached to the thing of Kanaria yellow at the end of an add-on name.
"s" is attached to the thing of sky blue at the end of an add-on name.

209-1000 series

    intro  retire   add-on name   payload weight  speed  power gear  cost   runningcost
01:1999.12 2015.01 JRE Tc209-1000   141     26t  110km/h            5700.00     0.22
02:1999.12 2015.01 JRE Tc208-1000   141     26t  110km/h            5700.00     0.22
03:1999.12 2015.01 JRE M209-1000    156     29t  110km/h 380kw 2.02 8500.00     0.34
04:1999.12 2015.01 JRE M208-1000    156     28t  110km/h 380kw 2.02 8400.00     0.33
05:1999.12 2015.01 JRE T209-1000    156     22t  110km/h            3100.00     0.12

Connection restriction is carried out so that only "JRE M 208-1000" can be connected with the next of "JRE M 209-1000."
"e" is attached to the thing of emerald green at the end of an add-on name.

E501 series

    intro  retire  add-on name payload weight  speed  power gear   cost   runningcost
01:1995.12 2011.01 JRE Tc_E501   146     26t  120km/h             6700.00     0.26
02:1995.12 2011.01 JRE Tc_E500   146     26t  120km/h             6800.00     0.26
03:1995.12 2011.01 JRE M_E501    146     34t  120km/h 480kw 1.73 10800.00     0.43
04:1995.12 2011.01 JRE M_E500    146     32t  120km/h 480kw 1.73 11000.00     0.44
05:1995.12 2011.01 JRE T_E501    162     23t  120km/h             3700.00     0.14

Connection restriction is carried out so that only "JRE M_E500" can be connected with the next of "JRE M_E501."
"e" is attached to the thing of emerald green at the end of an add-on name.


*The example of connection

Keihin-Tohoku Line (209-0 sky blue / 10 cars)
[Tc209][T209][M209][M208][T208][T209][T209][M209][M208][Tc208]

Nambu Line (209-0 Kanaria yellow and orange / 6 cars)
[Tc209][M209][M208][M209][M208][Tc208]

Kawagoe / Hachiko / Oume Line (209-3000 orange and uguisu green / 4 cars)
[Tc209][M209][M208][Tc208]

Chuo-Sobu Line (209-500 Kanaria yellow / 10 cars)
[Tc209][T209][M209][M208][T209][T209][T209][M209][M208][Tc208]

Keihin-Tohoku Line (209-500 sky blue / 10 cars)
[Tc209][T209][M209][M208][T209][T209][T209][M209][M208][Tc208]

Jo-ban Line (209-1000 sky blue / 10 cars)
[Tc209][M209][M208][T209][M209][M208][T209][M209][M208][Tc208]

Jo-ban Line (E501 emerald green / 15 cars)
[Tc_E501][T_E501][M_E501][M_E500][T_E501][T_E501][T_E501][M_E501][M_E500][Tc_E500][Tc_E501][M_E501][M_E500][T_E501][Tc_E500]


*Description about organization restrictions

Usually, on the train (new performance train) in Japan, apparatus required in order that an electric vehicle may move is distributed and carried in two or more vehicles.
Therefore, it cannot run only by one car but it is necessary to surely construct a unit by two or more vehicles.

In the case of the electric vehicle of 209 series, it is one unit in the following combination.
[JRE M209]-[JRE M208]

In the case of the electric vehicle of 209 series, it is one unit in the following combination.
[JRE M_E501]-[JRE M_E500]

Moreover, only vehicles with a driver's seat are made into the head and the tail end of a train.


*Introduction of japanese.simutrans.com

Most add-ons which Japanese people made are downloadable from http://www.japanese.simutrans.com/.
The add-on which also made HIBARI is first uploaded to japanese.simutrans.com :-)

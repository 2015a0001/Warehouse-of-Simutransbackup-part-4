ISUZU ELF Base vehicle
Copyright(c)HIBARI 2005/11/14

Thank you for downloading!:-)
This document was translated to the translation site.
I'm sorry when it is hard to read or there is a mistranslation.

*Introduction
ELF of ISUZU MOTORS was made as a material for reconstruction.
The diesel engine truck, the CNG truck, and the hybrid truck LPG truck were prepared.
Reconstruction is free if you can specify having converted and made ELF which the HIBARI made in Readme or a dat file.
As long as it encloses and distributes a png file and a dat file, you may distribute freely what was converted and made.
It is expected that various trucks will be exhibited :-)

JNR Steam locomotive set
Copyright(c)HIBARI Apr-09-2006
Document Corrected to Apr-26-2006

Thank you for downloading :-)
This document was translated to the translation site.
I'm sorry when it is hard to read or there is a mistranslation.


*Introduction

Since there was no steam locomotive of Japanese National Railways (JNR), it made.
Seven kinds of large-sized steam locomotives used in the trunk were made.

About distribution of this add-on, as long as it is within the limits of the following conditions, you may carry out freely.
1:Don't carry out distribution for the profit purpose.
2:Change no contents and copyright notation of this zip file.
3:Distribute this whole zip file.
However, if Mr. prissi or the development member of simutrans restricts when he puts this add-on into the new version of simutrans, on condition that copyright of a pak file is not changed, you may distribute with a pak file simple substance :-)

Installation only puts each "pak" file into the "pak" folder of Simutrans.
Since operation by versions other than Simutrans 86.03.4 and 88.05.1 is unidentified, please use it by your accountability.


*The list of an add-on included in this set

   [Intro] [Retire][Add-on name][Engine][Tender][Power] [Speed] [Gear]
01:1919.11 1966.02  JNR C51      68t     44t      881kw  95km/h  1.25
02:1928.-- 1950.09  JNR C53      81t     46t     1167kw 110km/h  1.25
03:1941.05 1970.09  JNR C59      80t     57t     1277kw 110km/h  1.25
04:1948.01 1973.10  JNR C62      89t     56t     1622kw 110km/h  1.25
05:1923.-- 1972.09  JNR D50      78t     49t     1133kw  75km/h  1.78
06:1936.02 1975.12  JNR D51      77t     46t     1180kw  75km/h  1.78
07:1943.12 1973.05  JNR D52      85t     52t     1462kw  75km/h  1.78

-The numerical value of each item is an add-on setting value.

-intro years and retire years are set as the real manufacture years and real disused car years of locomotive.
 However, there are some which have not set up intro month about what has the unknown manufacture month.


*Description of locomotives

C51 type steam locomotive (old name 18900 type steam locomotive)
It was made in 1928 after 1919.
It is the large-sized steam locomotive for passengers made for the first time in Japan.
It is the steam locomotive which adopted Pacific type (2C1) axis arrangement and 1750mm drive wheel for the first time by made in Japan.
It played an active part as a traction engine of a limited express or an express.

C53 type steam locomotive
Since it corresponds to the increase in train weight, it is the large-sized steam locomotive for passengers made in 1930 after 1928 as a succeeding steam locomotive of C51 type steam locomotive.
It is the only 3-cylinder type steam locomotive made in Japan.
It played an active part as a traction engine of a limited express or an express.

C59 type steam locomotive
It is the large-sized steam locomotive for passengers made in 1947 after 1941 as a succeeding steam locomotive of C53 type steam locomotive with the increase in passenger demand.
It is the completed type of a Japanese Pacific form steam locomotive.
It played an active part as a traction engine of a special express and an express.

C62 type steam locomotive
In order to compensate shortage of the engine for passengers after World War II, it is the steam locomotive for passengers of super-large-sized made in 1949 after 1948.
The boiler of D52 type steam locomotive was diverted, and it was made from the strongest steam locomotive in Japan.
It played an active part as a traction engine of the special express and express after World War II.

D50 type steam locomotive (old name 9900 type steam locomotive)
It is the large-sized steam locomotive for freight made in 1931 after 1923 aiming at the performance exceeding a 9600 type steam locomotive.
It is the steam locomotive which adopted Mikado type (1D1) axis arrangement and 1400mm drive wheel for the first time by made in Japan.
It became the foundation of the steam locomotive for freight made next.

D51 type steam locomotive
It is a large-sized steam locomotive for freight representing Japan where 1115 cars were made in 1945 after 1936.
With the steam locomotive which carried out improvement development of the D50 type, it was called "DEGOICHI" and loved.

D52 type steam locomotive
It is the steam locomotive for freight of super-large-sized made in 1946 after 1943.
During World War II, in order for freight ship to be sunk by the submarine, the demand of a freight train became high.
Since it corresponded to it, it was made as an engine which can lead a 1200t freight train.

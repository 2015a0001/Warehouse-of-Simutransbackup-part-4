JNR AND JR HIGHWAY BUS SET
Copyright(c)HIBARI 11/23/2005

Thank you for downloading! :-)
This document was translated to the translation site.
I'm sorry when it is hard to read or there is a mistranslation.

*Introduction
It is the set of JNR (Japanese National Railways) of Japan and the highway bus of JR Group (Japan Railway Group).
If it uses together with already distributed JAPANESE HIGHWAY TRUCK SET, all passenger and physical distribution transportation can also be provided only in the road.
The top speed of all buses is set as statute top speed 100 km/h of a highway of Japan.
Please use for directing the sight of the Japanese style :-)

After simutrans became a version corresponding to a road signal, he has noticed, but when going to north from south, and when the add-on made from the same specification as before was alike, and is going to the west from the east and it stops at a crossing, it is in the state of protruding a stop line.
The problem seems not to improve it by simutrans 87.02, either.
The vehicles which are contained in simutrans as standard are also protruded.
Since Pak coped with by that so that a stop line might not be protruded was enclosed to the "STOP-LINE" folder, please use here for the time being.
The direction using the version which does not support a road signal needs to use non-coped with Pak.
The file name and add-on name of Pak which has not been coped with and Pak coped with are set as the same thing.
From now on, the improvement in question should be made in the way of a system side, and when the way of Pak coped with comes to protrude a stop line, please transpose to Pak which has not been coped with.

Installation only puts each "pak" file into the "pak" folder of Simutrans.
Since operation by versions other than Simutrans 86.03.4 and 87.00 and 87.02 is unidentified, please use it by your accountability.

*About a Buses

FUSO MAR820(JNR)
MITSUBISHI FUSO MAR820
Power(Engine):290ps=213kw(Model:8DB20AT)
It is the bus manufactured for commencement of business of Meishin Highway Bus on October 5, 1964.
It has set up so that it may be introduced in October, 1964 and may retire in October, 1984.

FUSO B906R(JNR)
MITSUBISHI FUSO B906R
Power(Engine):350ps=257kw(Model:12DC)
It is the bus manufactured for commencement of business of Tomei Highway Bus on June 10, 1969.
It has set up so that it may be introduced in June, 1969 and may retire in June, 1989.

FUSO P-MS735SA(JNR)
MITSUBISHI FUSO P-MS735SA
Power(Engine):350ps=257kw(Model:8DC9T)
It is the first high-decker bus at JNR Highway Bus, and is the bus manufactured as the last form only for JNR.
The operation start was carried out by the Tomei Highway Bus from July 21, 1984.
It has set up so that it may be introduced in July, 1984 and may retire in July, 2004.

FUSO AEROQUEEN(JNR)
MITSUBISHI FUSO P-MU525TA AEROQUEEN W
Power(Engine):380ps=279kw(Model:8DC9T)
It is 3 axis super high-decker bus which is using AEROKING and a common chassis.
The operation start was carried out from December, 1986.
It applied immediately after from the JNR last stage after JR, and a large number were introduced.
It has set up so that it may be introduced in December, 1986 and may retire in December, 2006.

FUSO AEROKING(JR)
MITSUBISHI FUSO P-MU515TA AEROKING
Power(Engine):380ps=279kw(Model:8DC9T)
It is the double-decker bus put on the market in 1985, and came to be introduced as a highway bus after the 1990s when autocratic operation of a highway was attained by deregulation.
Although MU612TA which carried out improvement in an output will also be in 420ps(309kw) by minor model change in 1995, since neither appearance nor an output has a difference so much, it is not making there this time.
To an add-on name, it was not indicated that form could use also with the intention of MU612TA in 1995 and afterwards :-)
It is introduced in July, 1991 (with no retirement-from-service year setup).

FUSO NEW AEROBUS(JR)
MITSUBISHI FUSO KC-MS822P NEW AEROBUS
Power(Engine):420ps=309kw(Model:8M21)
It is the high-decker bus which carried out the minor model change of NEW AEROBUS whose model was changed fully in October, 1992 in May, 1995.
Since there is no difference in appearance and it has also seldom almost changed the output from U-MS821P after the full model change was undergone to KL-MS86M of the present age, please use with the intention of NEW AEROBUS series at large and the type of a car of liking (Therefore, form is not indicated to an add-on name).
It is introduced in May, 1995 (with no retirement-from-service year setup).

FUSO NEW AEROQUEEN(JR)
MITSUBISHI FUSO KC-MS822P NEW AEROQUEEN
Power(Engine):420ps=309kw(Model:8M21)
It is the super high-decker bus which carried out the minor model change of NEW AEROQUEEN whose model was changed fully in October, 1992 in May, 1995.
since there is no difference in appearance and it has also seldom almost changed the output from U-MS821P after the full model change was undergone to KL-MS86M of the present age, please use with the intention of NEW AEROQUEEN series at large and the type of a car of liking (therefore, form is not indicated to an add-on name).
It is introduced in May, 1995 (with no retirement-from-service year setup).

NEOPLAN MEGALINER(JR)
NEOPLAN N128/4 MEGALINER
Power(Engine):530ps=390kw(Model:0M442LA)
It is the first 15m double-decker bus in Japan at the product made from NEOPLAN of Germany.
The operation start was carried out from December 8, 2002 for the transportation improvement of the Tokyo station-Tsukuba center line which had become the shortage of transport capacity.
It is introduced in December, 2002 (with no retirement-from-service year setup).

JNR 201 series commuter train set
Copyright(c)HIBARI Apr-21-2006

Thank you for downloading :-)
This document was translated to the translation site.
I'm sorry when it is hard to read or there is a mistranslation.


*Introduction

201 series is commuter train of JNR (Japanese National Railways) manufactured from 1979 (completion of a mass-production vehicle is 1981) to 1985.
In Japan, the color of the body was changed according to the route by general train.
It is a train supporting the commutation transportation from a Japanese post-war economic miracle term to the present age.
It was developed as an "energy-saving train" which adopted armature chopper control and an electric power regeneration brake.

Since he wanted colorful commuter train, it made.
It made simultaneously with "JNR 101 series commuter train set" and "JNR 103 series commuter train set."

Installation only puts each pak file into the "pak" folder of simutrans.
The check of operation was carried out by the versions 86.03.4, 88.05.1, and 88.08.1 of simutrans.
Although it is making carefully so that it may operate normally, a trouble may arise in operation of simutrans on balance with other add-ons.
Moreover, it may not operate normally by other versions.
I cannot have responsibility to the possibility of those troubles.
Please judge with responsibility whether this add-on is used.

About distribution of this add-on, as long as it is within the limits of the following conditions, you may carry out freely.
1:Don't carry out distribution for the profit purpose.
2:Change no contents and copyright notation of this zip file.
3:Distribute this whole zip file.

However, if Mr. prissi or the development member of simutrans restricts when he puts this add-on into the new version or pakjapan64 of simutrans, on condition that copyright of a pak file is not changed, you may distribute with a pak file simple substance :-)

It is prohibition to distribute what changed this add-on.
It is prohibition that what has not permitted to change also about all the add-ons that HIBARI exhibited until now distributes the changed add-on.


*The pak file included in this set

The pak file is divided according to the body color.
If the thing of all colors is installed, it will be hard coming to see a garage window.
I consider that it is better to install only the thing of a color to use.

01:vehicle.JNR_201.pak   Player color
02:vehicle.JNR_201o.pak  Orange vermilion
03:vehicle.JNR_201k.pak  Kanaria yellow (=Canary yellow)
04:vehicle.JNR_201s.pak  Sky blue


*A list of an add-on

   intro   retire  add-on name   payload weight speed   power gear cost     runningcost
01:1979.08 1985.04 JNR Tc201     136     33t    100km/h             9300.00 0.46
02:1979.08 1985.04 JNR Tc200     136     33t    100km/h             9300.00 0.46
03:1979.08 1985.04 JNR M201      144     42t    100km/h 600kw 1.60 14900.00 0.74
04:1979.08 1985.04 JNR M200      144     42t    100km/h 600kw 1.60 14900.00 0.74
05:1979.08 1985.04 JNR T201      144     31t    100km/h             5600.00 0.27

As for the thing of Orange vermilion, "o" is attached to the end of add-on name.
As for the thing of Kanaria yellow (=Canary yellow), "k" is attached to the end of add-on name.
As for the thing of Sky blue, "s" is attached to the end of add-on name.

The value of each above-mentioned item is a value set as an add-on.

It is only JNR Tc200 that being made at the head of a train is made by only JNR Tc201 in the tail end.
Connection restriction is carried out so that only JNR M200 cannot be connected behind JNR M201.
Connection restriction is carried out so that only JNR M201 cannot be connected before JNR M200.


*The example of connection

Chuo Line (Orange vermilion)
[JNR Tc201][JNR M201][JNR M200][JNR Tc200][JNR Tc201][JNR M201][JNR M200][JNR M201][JNR M200][JNR Tc200]
[JNR Tc201][JNR M201][JNR M200][JNR T201][JNR M201][JNR M200][JNR T201][JNR M201][JNR M200][JNR Tc200]

Keihanshin Line (sky blue)
[JNR Tc201][JNR M201][JNR M200][JNR T201][JNR M201][JNR M200][JNR Tc200]


*Description about organization restrictions

Usually, on the train (new performance train) in Japan, apparatus required in order that an electric vehicle may move is distributed and carried in two or more vehicles.
Therefore, it cannot run only by one car but it is necessary to surely construct a unit by two or more vehicles.

In the case of the electric vehicle of 201 series, it is one unit in the following combination.
[JNR Mc201]�\[JNR M200]

Moreover, only vehicles with a driver's seat are made into the head and the tail end of a train.


*Introduction of japanese.simutrans.com

Most add-ons which Japanese people made are downloadable from http://www.japanese.simutrans.com/.
The add-on which also made HIBARI is first uploaded to japanese.simutrans.com :-)

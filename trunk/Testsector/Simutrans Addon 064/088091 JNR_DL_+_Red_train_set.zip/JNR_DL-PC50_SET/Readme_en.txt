JNR diesel locomotive plus red train set
Copyright(c)HIBARI Mar-27-2006
Document Corrected to Apr-26-2006

Thank you for downloading :-)
This document was translated to the translation site.
I'm sorry when it is hard to read or there is a mistranslation.


*Introduction

They are the diesel locomotives DF50 and DD54 of Japanese National Railways (JNR), and the set of the 50 series passenger car.
Since the 50 series passenger car was the red body, it was called the red train.
Since connection restrictions have not been carried out to the 50 series passenger car, the engine of JNR AC electric locomotives and Multisystem locomotives set can also be led.

About distribution of this add-on, as long as it is within the limits of the following conditions, you may carry out freely.
1:Don't carry out distribution for the profit purpose.
2:Change no contents and copyright notation of this zip file.
3:Distribute this whole zip file.
However, if Mr. prissi or the development member of simutrans restricts when he puts this add-on into the new version of simutrans, on condition that copyright of a pak file is not changed, you may distribute with a pak file simple substance :-)

Installation only puts each "pak" file into the "pak" folder of Simutrans.
Since operation by versions other than Simutrans 86.03.4 and 88.05.1 is unidentified, please use it by your accountability.


*The list of an add-on included in this set

   [Intro] [Retire][Add-on name][Weight][Power][Speed] [Payload]
01:1957.03-1985.01 DF50         83t      600kW  90km/h ---
02:1966.06-1978.12 DD54         70t     1365kW  95km/h ---
03:1977.00-        OHA50�@      28t     ------  95km/h 112 passengers
04:1977.00-        OHAFU50      30t     ------  95km/h  92 passengers
05:1977.00-        MANI50       29t     ------  95km/h  43 crates piece goods
06:1977.00-        SUYUNI50     32t     ------  95km/h 160 bags Mail
07:1987.00-�@�@�@  OHA50-5000   22t     ------ 110km/h  68 passengers
08:1987.00-        OHAFU50-5000 30t     ------ 110km/h  52 passengers

-The value of each above-mentioned item is an add-on setting value (weight has rounded off the weight of a real vehicle).
-Intro month is not set to what is 00.


*About vehicles

DF50
It is the Diesel-electric engine for non-electrification trunks made from 1956.
What manufactured under license the engine which is 1060PS (=795kw) of outputs which SULZER designed, and the engine which is 1200PS (=900kw) of outputs which MAN designed was used for the engine for power generation.
As for the motor for a drive, six 100kW motors are used, and the output has become 600kW in total.

DD54
It is the Diesel-hydraulic engine for the low routes of a weight limit made from 1966.
It had the body of a European style and what carried out the license production of torque converter of MEKYDRO to 1820PS (=1365kW) engine of outputs which MAYBACH designed was used.
Although it was the engine with which the new device was incorporated, since failure and the accident succeeded one another from immediately after the appearance, the disused car was carried out for a short period of time.

OHA50
It is passenger car made from 1977 for replacement of an improvement of the transportation capability of the route around a local city and the superannuated old model passenger car.
Compared with the old model passenger car, modernization is attained sharply.

OHAFU50
It is passenger car to which the hand brake used for OHA50, the conductor room made at the period, and an emergency is attached.
Usually, it connects with the front row or the tail end of organization.

MANI50
It is the load car made from 1977 for replacement of the superannuated old model load vehicle.

SUYUNI50
It is the combination baggage and mail van made from the form which diverts a cart, a connector, etc. from the old form coach based on MANI50 type, and carries out the product made from new only of the body.

OHA50-5000
It is passenger car which converted OHA50 in 1987 and was made for the rapid-transit trains of Seikan Tunnel (Tsugaru Kaikyo Line).
Upgrades, such as formation of a large-sized double-glazed glass window, air-conditioning-izing, and formation of a conversion cross seat, are achieved.
Moreover, it is exchanged for the thing of the 14 series passenger car in the cart, and top speed improved to 110 km/h.

OHAFU50-5000
It is the lenience-and-severity car which converted OHAFU50 in 1987 and was made for the rapid-transit trains of Seikan Tunnel (Tsugaru Kaikyo Line).
The same upgrade as OHA 50-5000 is achieved.

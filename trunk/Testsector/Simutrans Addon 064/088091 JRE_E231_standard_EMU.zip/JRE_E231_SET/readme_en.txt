JR East E231 series standard EMU set
Copyright(c)HIBARI May-18-2006

Thank you for downloading :-)
This document was translated to the translation website.
I'm sorry when it is hard to read or there is a mistranslation.


*Introduction

E231series EMU is direct-current standard EMU of JR East (East Japan Railway Company) which appeared in 2000.
standard EMU unifies conventional commuter EMU (209 series) and conventional suburbs type EMU (E217 series).
Therefore, there is a thing of commuter type and suburbs type in E231series within the same series.

E231-0 series was developed as an inheritor of 103 series EMU of Chuo-Sobu Line, and appeared in 2000.

E231-500 series was developed as an inheritor of 205 series EMU of Yamanote Line, and appeared in 2002.

E231-800 series was developed for direct operation with Tokyo Metro Tozai Line, and appeared in 2003.

Suburbs type was developed as an inheritor of 113 and 115series EMU of Tohoku main Line and Tokaido Main Line, and appeared in 2000.
Green Car of 2 stories is connected from 2004.

Installation only puts the pak file of an add-on to use into simutrans/pak/ folder :-)

It checked operating by the following versions.
86.03.4
88.06.3
88.09.1
Operation by other versions is not checked.
The trouble which is not expected depending on usage's PC environment may arise.
I cannot have responsibility to the possibility of those troubles.
Please judge with responsibility whether this add-on is used by that.

About distribution of this add-on, as long as it is within the limits of the following conditions, you may carry out freely.
1:Don't carry out distribution for the profit purpose.
2:Change no contents and copyright notation of this zip file.
3:Distribute this whole zip file.
However, when putting in and distributing this add-on to the main simutrans game, on condition that the contents of the pak file are not changed, you may distribute with a pak file simple substance.


*The pak file included in this set

The pak file is divided according to the body color.
Since vehicles will increase in number too much if all color installations are carried out, it is hard coming to choose vehicles in a garage window.
We recommend you to install only the thing of a color to use.

01:vehicle.JRE_E231.pak      E231-0 player color
02:vehicle.JRE_E231k.pak     E231-0 kanaria yellow
03:vehicle.JRE_E231e.pak     E231-0 emerald green
04:vehicle.JRE_E231-500.pak  E231-500 player color
05:vehicle.JRE_E231-500u.pak E231-500 uguisu green
06:vehicle.JRE_E231-800.pak  E231-800 player color
07:vehicle.JRE_E231-800b.pak E231-800 blue
08:vehicle.JRE_E231_.pak     E231 suburbs type player color
09:vehicle.JRE_E231_og.pak   E231 suburbs type orange and green


*A list of an add-on

E231-0 series

    intro  retire  add-on name payload weight  speed  power gear  cost   runningcost
01:2000.03 2015.04 JRE Tc_E231   147     26t  120km/h            6000.00     0.23
02:2000.03 2015.04 JRE Tc_E230   147     26t  120km/h            6000.00     0.23
03:2000.03 2015.04 JRE M_E231    162     28t  120km/h 380kw 2.02 8700.00     0.34
04:2000.03 2015.04 JRE M_E230    162     28t  120km/h 380kw 2.02 8700.00     0.34
05:2000.03 2015.04 JRE T_E231    162     22t  120km/h            3300.00     0.13
06:2000.03 2015.04 JRE T_E230    160     24t  120km/h            3500.00     0.13

Connection restriction is carried out so that only "JRE M_E230" can be connected with the next of "JRE M_E231."
"k" is attached to the thing of kanaria yellow at the end of an add-on name.
"e" is attached to the thing of emerald green at the end of an add-on name.
Six door car (T_E230) is not one of the things of emerald green.

E231-500 series

    intro  retire    add-on name    payload weight  speed  power gear  cost   runningcost
01:2002.04 2017.05 JRE Tc_E231-500    147     26t  120km/h            6000.00     0.23
02:2002.04 2017.05 JRE Tc_E230-500    147     26t  120km/h            6000.00     0.23
03:2002.04 2017.05 JRE M_E231-500     162     29t  120km/h 380kw 2.02 8700.00     0.35
04:2002.04 2017.05 JRE M_E230-500     162     29t  120km/h 380kw 2.02 8700.00     0.35
05:2002.04 2017.05 JRE T_E231-500     162     23t  120km/h            3300.00     0.13
06:2002.04 2017.05 JRE T_E230-500     162     24t  120km/h            3500.00     0.13

Connection restriction is carried out so that only "JRE M_E 230-500" can be connected after "JRE M_E 231-500."
"u" is attached to the thing of uguisu green at the end of an add-on name.

E231-800 series

    intro  retire    add-on name   payload weight  speed  power gear  cost   runningcost
01:2003.05 2018.06 JRE Tc_E231-800   141     26t  120km/h            6000.00     0.23
02:2003.05 2018.06 JRE Tc_E230-800   141     26t  120km/h            6000.00     0.23
03:2003.05 2018.06 JRE M_E231-800    156     29t  120km/h 380kw 2.02 8700.00     0.35
04:2003.05 2018.06 JRE M_E230-800    156     29t  120km/h 380kw 2.02 8700.00     0.35
05:2003.05 2018.06 JRE T_E231-800    156     23t  120km/h            3300.00     0.13

Connection restriction is carried out so that only "JRE M_E 230-800" can be connected after "JRE M_E 231-800."
"b" is attached to the thing of a blue color at the end of an add-on name.

E231 suburbs type

    intro  retire   add-on name payload weight  speed  power gear  cost   runningcost
01:2000.06 2015.07 JRE Tc_E231_   143     26t  120km/h            6000.00     0.23
02:2000.06 2015.07 JRE Tc_E230_   138     28t  120km/h            6300.00     0.24
03:2000.06 2015.07 JRE M_E231_    162     28t  120km/h 380kw 2.02 8500.00     0.34
04:2000.06 2015.07 JRE M_E230_    162     30t  120km/h 380kw 2.02 9000.00     0.36
05:2000.06 2015.07 JRE T_E231_    162     22t  120km/h            3300.00     0.13
06:2004.07 2015.07 JRE T_E230_     90     35t  120km/h            4200.00     0.16

Connection restriction is carried out so that only "JRE M_E230_" can be connected after "JRE M_E231_."
"og" is attached to the thing of the orange and green at the end of an add-on name.


*The example of connection

Chuo-Sobu Line (E231-0 kanaria yellow / 10 cars)
[Tc_E231][TE_231][M_E231][M_E230][T_E230][T_E231][T_E231][M_E231][M_E230][Tc_E230]

Jo-ban Line (E231-0 emerald green / 15 cars)
[Tc_E231][T_E231][M_E231][M_E230][Tc_E230][Tc_E231][T_E231][M_E231][M_E230][T_E231][T_E231][T_E231][M_E231][M_E230][Tc_E230]

Yamanote Line (E231-500 uguisu green / 11 cars)
[Tc_E231][T_E231][M_E231][M_E230][T_E230][M_E231][M_E230][T_E231][M_E231][M_E230][Tc_E230]

Chuo-Sobu Line - Tokyo Metro Tozai Line direct operation (E231-800 blue / 10 cars)
[Tc_E231][M_E231][M_E230][T_E231][M_E231][M_E230][TE231][M_E231][M_E230][Tc_E230]

Tohoku main Line and Tokaido Main Line (E231 suburbs type orange and green / 15 cars)
[Tc_E231][T_E231][M_E231][M_E230][Tc_E230][Tc_E231][M_E231][M_E230][T_E231][T_E231][T_E230][T_E230][M_E231][M_E230][Tc_E230]


*Description about organization restrictions

Usually, on the train (new performance train) in Japan, apparatus required in order that an electric vehicle may move is distributed and carried in two or more vehicles.
Therefore, it cannot run only by one car but it is necessary to surely construct a unit by two or more vehicles.

In the case of the electric vehicle of E231 series, it is one unit in the following combination.
[JRE M_E231]-[JRE M_E230]

Moreover, only vehicles with a driver's seat are made into the head and the tail end of a train.


*Introduction of japanese.simutrans.com

Most add-ons which Japanese people made are downloadable from http://www.japanese.simutrans.com/.
The add-on which also made HIBARI is first uploaded to japanese.simutrans.com :-)

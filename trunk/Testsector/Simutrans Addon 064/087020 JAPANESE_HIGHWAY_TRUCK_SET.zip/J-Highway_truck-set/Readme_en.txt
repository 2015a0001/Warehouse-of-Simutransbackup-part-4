JAPANESE HIGHWAY TRUCK SET
Copyright(c)HIBARI 10/28/2005
Corrected to 11/23/2005

Thank you for downloading! :-)
This document was translated to the translation site.
I'm sorry when it is hard to read or there is a mistranslation.

*Introduction
These trucks are BigThumb of NISSAN DIESEL MOTOR (UD).
Wearing obligation of the Speed Limiter with which a Japanese heavy-duty truck controls speed to 90km/h has started on September 1, 2003.
Therefore, the truck of this set has also set top speed as 90km/h.
A gear ratio is set up more highly and the acceleration performance is improved.
Since all trucks are the same top speed, if shipping freight traffic is carried out only by truck of this set, traffic congestion cannot take place easily, and it can come out and perform conveying smoothly.
Moreover, if a certain amount of number is used collectively, it is also possible to change the means of shipping freight traffic to a truck completely from a railroad.
Since Japan has more truck line than railroad transportation, it can use also for directing the sight of the Japanese style.

After simutrans became a version corresponding to a road signal, he has noticed, but when going to north from south, and when the add-on made from the same specification as before was alike, and is going to the west from the east and it stops at a crossing, it is in the state of protruding a stop line.
The problem seems not to improve it by simutrans 87.02, either.
The vehicles which are contained in simutrans as standard are also protruded.
Since Pak coped with by that so that a stop line might not be protruded was enclosed to the "STOP-LINE" folder, please use here for the time being.
The direction using the version which does not support a road signal needs to use non-coped with Pak.
The file name and add-on name of Pak which has not been coped with and Pak coped with are set as the same thing.
From now on, the improvement in question should be made in the way of a system side, and when the way of Pak coped with comes to protrude a stop line, please transpose to Pak which has not been coped with.

Installation only puts each "pak" file into the "pak" folder of Simutrans.
Since operation by versions other than Simutrans 86.03.4 and 87.00 and 87.02 is unidentified, please use it by your accountability.

*About a trucks

01.UD Highway Mail truck
   Capacity:176bags Mail
   Japan Post color

02.UD Steel trailer
   Capacity:40t Steel
   Player color

03.UD Steel trailer(NITTSU)
   The Nippon Express color version of No. 02

04.UD Plastics truck
   Capacity:15t Plastics

05.UD Plastics truck(NITTSU)
   The Nippon Express color version of No. 04

06.UD Paper trailer
   Capacity:23t Paper
   Player color

07.UD Paper trailer(NITTSU)
   The Nippon Express color version of No. 06

08.UD Wood trailer
   Capacity:23t Wood
   Player color

09.UD Planks trailer
   Capacity:23t Planks
   Player color

10.UD Milk tanker
   Capacity:15m3 Milk
   Player color
   It is necessary to install 64 Food industry chain Pak.

11.UD Concrete mixer
   Capacity:15t Concrete
   Player color

12.UD Concrete mixer(TAIHEIYO)
   The Taiheiyo Cement color version of No. 11

13.UD Cement truck
   Capacity:15t Cement
   Player color

14.UD Cement truck(TAIHEIYO)
   The Taiheiyo Cement color version of No. 13

15.UD Car transporter
   Capacity:5 Cars
   Player color

16.UD Goods truck
   Capacity:50crates piece goods
   Player color

17.UD Goods truck(NITTSU)
   The Nippon Express color version of No. 16

18.UD Goods truck(YAMATO)
   The Yamato Transport color version of No. 16

19.UD Goods truck(SEINO)
   The Seino Transportation color version of No. 16

20.UD Goods truck(FUKUTSU)
   The Fukuyama Transporting color version of No. 16

21.UD Goods truck(SAGAWA)
   The Sagawa Express color version of No. 16

22.UD Dump truck
   Capacity:15t bulk goods
   Player color

23.UD Dump truck 2
   Capacity:15t bulk goods
   Player color

24.UD Oil tanker
   Capacity:20m3 oil/gasoline
   Player color

25.UD Oil tanker(IDEMITSU)
   The Idemitsu Kosan color version of No. 24

26.UD Oil tanker(Shell)
   The Showa Shell Sekiyu color version of No. 24

27.UD Oil tanker(ENEOS)
   The ENEOS(Nippon Oil) color version of No. 24

28.UD Oil tanker(COSMO)
   The Cosmo Oil color version of No. 24

29.UD Refrigerator truck
   Capacity:50crates cooled goods
   Player color
   It is necessary to install 64 Food industry chain Pak.

30.UD Refrigerator truck(NICHIREI)
   The Nichirei color version of No. 29
   It is necessary to install 64 Food industry chain Pak.

JNR 113 (c)Kikin Sharyo  Jan/5/2004
Thank you for your download.
I permit you distribution and reconstruction and etc.
Don't forget include "JNR 113(engine)", when you making up a train.
This train is very popular in Japan.
-------------------------------------------------------------------------------
  South Manchuria Railways Limited Express "Asia"

  Steam Locomotive "Pacina"
  Baggage/Mail car TEYU-8
  3rd Grade Passanger Coach HA-8
  Dining Car SHI-8
  2nd Grade Passanger Coach RO-8
  1st Grade Passanger Coach I-8
  1st Grade Obserbation TENNI-8

    Copyright 2006 EF-85 (Base graphics by 939)
-------------------------------------------------------------------------------

 Thank you for downloading. 

 Limited express "Asia" ran through the plain of Manchukuo as a symbol of South
Manchuria Railways (SMR).

 It is the add-on which I began and which was made. Watch it with the warm eyes
though it thinks that there is a part which doesn't reach it very much.

 As for the tune side composition of the passenger car, it let me refer to class 20
passenger coach of Mr.939. I appreciates Mr.939.


 * About "Asia"

 Because a limited express "Asia" was constructed, the essence of the Japanese
railroad technology was collected. 
 A streamline steam locomotive was the name of "Pacina". That is the meaning of the
seventh model of class Pacific (4-6-2) steam locomotive.
 A luxurious streamline passenger cars was equipped with the air-conditioning well
in the world for the first time. 
 It drove at a rating speed which was faster by more than 10km/h than the fastest 
limited express "Tsubame" in Japan.
 In November, 1934, the capital Xi-nji-ng is connected with port town Dalian, business 
operation start. It was extended to Harbin of the hinterland in next year September 
and popularity was collected as a symbol of SMR. But, that life was finished only at
8 years in February, 1943 because of the war.
 Its locomotives and Carriages were requisitioned by China after the collapse of
Manchukuo, and it was used. At present, one unit of "Pacina" is displayed in Shenyang
steam locomotive museum.


 * Composition Guide

 Basic composition is six cars. From the head, Baggage/Mail car, 2 of 3rd Grade Coach,
Dining Car, 2nd Grade Coach and 1st Grade Obserbation. One 1st Grade Passanger
Coach or 2nd Grade Coach could be added between 2nd Grade Coach and 
1st Grade Obserbation.

 3rd Grade Coach and 2nd Grade Coach can be increased freely in game.


 * About the performance

 It is set up so that it may be possible that which is 160km/h only the locomotive
as to the design speed is taken out. It is meaningless because other Carriages can't
be connected.
 There were a few materials for the locomotive, and it didn't find out the power and a
gear ratio. So, it is set up so that high-speed operation may be possible referring to
the performance of the American limited express of the same age contained in the
Pak128 and so on. Teach to me if you know the numerical value of the power and
the gear ratio, please.
 
 Set up in the retirement term in the date when business operation was stopped.

ABUKYU SET
Copyright(c)HIBARI Sep-24-2006
Revision Sep-30-2006

Thank you for downloading :-)
This document was translated to the translation website.
I'm sorry when it is hard to read or there is a mistranslation.


*Introduction

Abukuma Express.,ltd is the railroad company in Japan which has connected the Fukushima station of Fukushima Prefecture, and the Tsukinoki station of Miyagi Prefecture.
There is the 54.9km of the length of a route.
In Japanese, the thing of Abukuma Express is called "Abukuma Kyuko."
It is usually omitted and it is referred to as "Abukyu."
The route of AbukumaExpress was a route planned as a bypass line of Tohoku Line from the first.
Between the Marumori-station started business as a Marumori line (a length of 17.4km) of JNR (Japanese National Railways) from the Tsukinoki station on April 1, 1968.
The Marumori line will be abolished by the JNR rebuilding method after that.
Abukuma Express.,ltd was born in the form which third-sector-izes the Marumori line on July 1, 1986.
Then, it extends to the Fukushima station, electrifies by AC20kV (50Hz), and has resulted soon.

ABUKYU 8100 series EMU which combined and appeared in electrification, and ABUKYU KIHA22 type DC currently used before electrification are contained in this set.
Moreover, JNR KIHA22 type DC of Metropolitan area color and JNR standard color was also enclosed for the addition.

Installation only puts the pak file of an add-on to use into simutrans/pak/folder ;-)

It checked operating by the following versions.
86.03.4
88.06.3
88.09.1
Operation by other versions is not checked.
The trouble which is not expected depending on usage's PC environment may arise.
I cannot have responsibility to the possibility of those troubles.
Please judge with responsibility whether this add-on is used by that.

About distribution of this add-on, as long as it is within the limits of the following conditions, you may carry out freely.
1: Don't carry out distribution for the profit purpose.
2: Change no contents and copyright notation of this zip file.
3: Distribute this whole zip file.
However, when putting in and distributing this add-on to the main simutrans game, on condition that the contents of the pak file are not changed, you may distribute with a pak file simple substance.


*A list of an add-on

01:ABUKYU 8100 series EMU (file name:vehicle.ABUKYU_8100.pak)
 intro    :1988.07
 retire   :2013.08
 formation:[ABUKYU AM8100][ABUKYU AT8100]

02:ABUKYU KIHA22 type DC (file name:vehicle.ABUKYU_KIHA22.pak)
 intro    :1986.07
 retire   :1988.07
 formation:[ABUKYU KIHA22]

03:JNR KIHA22 type DC Metropolitan area color=Vermilion (file name:vehicle.JNR_KIHA22v.pak)
 intro    :1980.01
 retire   :1992.03
 formation:[JNR KIHA22v]

04:JNR KIHA22 type DC JNR standard color (file name:vehicle.JNR_KIHA22.pak)
 intro    :1958.10
 retire   :1980.01
 formation:[JNR KIHA22]


*Introduction of japanese.simutrans.com

Most add-ons which Japanese people made are downloadable from http://www.japanese.simutrans.com/.
The add-on which also made HIBARI is first uploaded to japanese.simutrans.com :-)

Sendai city Transportation Bureau train set
Copyright(c)HIBARI 09/18/2005
2006/04/25 updating (the Pak file was updated)

Thank you for downloading!
This document was translated to the translation site.
I'm sorry when it is hard to read or there is a mistranslation.

*Introduction

In Sendai city Transportation Bureau (Sendai city of Miyagi Prefecture in Japan), Senday Tramway is operated a long time ago, and the Sendai subway and the Sendai city-owned bus are operated now.
Senday Tramway is the streetcar to which it had connected the Sendai in the city opened on November 25, 1926.
Although 16.0km of working kilometers was reached in the golden age, it became whole-line abolition on March 31, 1976.
The Sendai subway is a subway of 14.8km of working kilometers which connect between Izumi-chuo to Tomizawa of Sendai city.
Between Tomizawa and Yaotome extends on July 15, 1987, between a Yaotome and Izumi-chuo extends on commencement of business and July 15, 1992, and it has continued up to now.

Four kinds of lower vehicles are contained in this vehicle set.
 Senday Tramway MOHA 1 type train
 Senday Tramway MOHA 100 type train
 Senday Tramway MOHA 400 type train
 Sendai subway 1000 series train

Installation only puts each "pak" file into the "pak" folder of Simutrans.
Since operation by versions other than Simutrans 86.03.4 and 88.08.1 is unidentified, please use it by your accountability.

*About a vehicle

Senday Tramway MOHA 1 type train
It is the train of the wooden body 2 axis cart manufactured in Kawasaki Shipyard Co. in September, 1926.
It was introduced at the time of street car commencement of business, and played an active part to abolition.
Although it had become the body color of the same green keynote as MOHA100 type etc. the second half, one car is returned to the reddish brown at the time of commencement of business at the time of abolition.
It is introduced in September, 1926, and it has set up so that it may retire in July, 1952.

Senday Tramway MOHA 100 type train
It is the train of the half-steel body manufactured in Niigata Engineering Co., Ltd. in July, 1952.
It was the prime train of the Sendai street car which came out as first bogie car MOHA80 type in the Sendai street car. (The number is changed into MOHA100 type in 1954)
It is introduced in July, 1952, and it has set up so that it may retire in April, 1963.

Senday Tramway MOHA 400 type train
It is the train of the steel body manufactured in the Nippon Sharyo, Ltd. in April, 1963.
It is the train newly built at the end by Senday Tramway.
Autoparts etc. are used for this train and improvement in conservativeness and cost reduction are planned.
It is introduced in April, 1963, and it has set up so that it may retire in March, 1976.

Sendai subway 1000 series train
It is playing an active part in the train of the aluminum body manufactured in Kawasaki Heavy Industries, Ltd. in 1986 from the time of subway commencement of business to the present.
The fuzzy control of fashion is taken in those days and automatic operation is attained by ATC-PTC-ATO.
Moreover, armature chopper control and a regeneration brake are adopted, and energy saving is also attained. (The renewal vehicle is VVVF inverter control)
It is operated from the time of commencement of business to the present by four-car organization of "11xx(Tc1)-12xx(M1)-13xx(M2)-16xx (Tc2)" (xx is an organization number).
When users increase in number, the unit of "M1-M2" is inserted and it has come be made to "11xx(Tc1)-12xx(M1)-13xx(M2)-14xx(M1)-15xx(M2)-16xx (Tc2)" six-car organization.
It is introduced in 1986. (The retirement-from-service year has not set up)

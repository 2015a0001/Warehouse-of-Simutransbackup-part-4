simutrans -objects pak.german/

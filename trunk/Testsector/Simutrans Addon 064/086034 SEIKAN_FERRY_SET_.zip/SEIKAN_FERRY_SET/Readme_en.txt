SEIKAN FERRY SET
Copyright(c)HIBARI 10/10/2005
Corrected to 02/16/2006

Thank you for downloading!:-)
This document was translated to the translation site.
I'm sorry when it is hard to read or there is a mistranslation.


*Introduction

Before Seikan Tunnel starts business, it is the set of Seikan ferry which had connected between the Aomori station of Aomori Prefecture, and the Hakodate stations in Hokkaido.
As for Seikan ferry, the Japanese National Railways (JNR) and Hokkaido Railway Company (JR Hokkaido) plied.
Cargo ADD is introduced and it enabled it to carry various cargo together with a passenger by 1 boat :-).

Installation is O.K. only by putting each "pak" file into the "pak" folder of Simutrans.
Since operation by versions other than Simutrans 86.03.4 and 88.01.3 and 88.03.2 is unidentified, please use it by your accountability.


*The list of an add-on included in this set

   [Intro] [Retire] [Add-on name]             [Passenger]
01:1924.05-1947.11  Seikan Shoho-maru ferry          895
02:1947.11-1964.05  Seikan Toya-maru ferry          1128
03:1957.10-1966.10  Seikan Towada-maru ferry        1470
04:1964.05-----.--  Seikan Tsugaru-maru ferry       1286

-What has not filled in retirement-from-service years has not set up retirement-from-service years.
-As for 04, a hull color changes according to a player color.


*About Cargo ADD

Cargo ADD can be carried in 1 boat to three.
Two kinds, SIMPLE_ADD and REAL_ADD, are prepared according to usage.

SIMPLE_ADD has set 27 cars (15t product freight car) of the amount average of vehicles loading of all ships to the standard.
The freight per ADD is nine cars (135t).
It is introduced in May, 1924.
The retirement-from-service year has not set up.

REAL_ADD has set the amount of vehicles loading at each ship time to the standard.
The freight per ADD is 1/3 of the amount of vehicles loading (the fraction has omitted).
According to introduction and retirement from service of each ship, introduction and retirement from service of are done.

The direction which does not want to increase those who turn OFF the time line and are playing, and the number of introduction of Cargo ADD recommends you use of SIMPLE_ADD.
Those who enable it to want to be able to carry cargo comparable as an actual ship, and turn ON the time line and are playing need to use REAL_ADD.

The food production Pak (food64) needs to be introduced to use the following cargo ADD.
Keep in mind that Simutrans will not start if it installs in the environment which is not introduced.
[SIMPLE_ADD]
 vehicle.Seikan-cooled_goods.pak
 vehicle.Seikan-milk.pak
[REAL_ADD]
 vehicle.Shoho-cooled_goods.pak
 vehicle.Shoho-milk.pak
 vehicle.Toya-Towada-cooled_goods.pak
 vehicle.Toya-Towada-milk.pak
 vehicle.Tsugaru-cooled_goods.pak
 vehicle.Tsugaru-milk.pak

Garbage Pak (waste64) needs to be introduced to use the following cargo ADD.
Keep in mind that Simutrans will not start if it installs in the environment which is not introduced.
[SIMPLE_ADD]
 vehicle.Seikan-waste.pak
[REAL_ADD]
 vehicle.Shoho-waste.pak
 vehicle.Toya-Towada-waste.pak
 vehicle.Tsugaru-waste.pak


*About a ship

Shoho-maru type ferry
It went into commission on Shoho-maru type ferry May 21, 1924.
It is the ship which a freight car also puts together with the first passenger by Seikan ferry.
The same type ship is 4 boats, Shoho-maru, Tsugaru-maru1, Matsumae-maru1, and Hiran-maru.
The rail of three lines is laid in the vehicle deck, and the 15t boxcar was able to be carried 25 cars.
Between Hakodate was connected in 4 hours and 30 minutes to Aomori.
Although it was the main force of Seikan ferry before World War II, 4 boats sank for the Seikan ferry air raid on July 14, 1945.
Retirement is postponed until Toya-maru type goes into commission, since there is no war in the world of Simutrans.

Toya-maru type ferry
It went into commission on November 21, 1947.
It is full-scale ferry newly built after World War II.
The same type ship is 4 boats, Toya-maru, Yotei-maru I, Mashu-maru I, and Taisetsu-maru I.
The rail of two lines is laid in the vehicle deck, and the 15t boxcar was able to be carried 18 cars.
Between Hakodate was connected in 4 hours and 30 minutes to Aomori.
It was the ship by which it was expected as a role of a lead of revival after the war that a radar is carried in Toya-maru for the first time with a Japanese merchant vessel on October 18, 1950, and His Majesty the Emperor boards on August 7, 1954 etc.
For the storm reason of a typhoon No.15 (the Japan name a Toya-maru typhoon and the U.S. name Marie), overthrow sinking was carried out on September 26, 1954, and the short whole life was closed.
By this typhoon, four connection ships are also wrecked besides Toya-maru. The 2nd 1430 victims in the world were sacrificed in the history of the marine accident.
This was a marine accident with many victims at the next of Titanic sinking.
A vehicles loading mouth was not equipped with the watertight door at the connection ship to that time.
Since the defect on the structure was also the cause of overthrow sinking, the connection ship made after it came (extension construction was performed on the non-equipped ship) to be equipped with a watertight door.
Moreover, the ship of Toya-maru type which remained was able to change the color of a hull into the same green as Towada-maru I.

Towada-maru type ferry
It is the first diesel boat at Seikan ferry which was built instead of sunken Toya-maru and went into commission on October 1, 1957 (2 boats described above are a steam turbine ship).
There was no same type ship and this model was only 1 boat of Towada-maru I.
The rail of two lines is laid in the vehicle deck, and the 15t boxcar was able to be carried 18 cars.
The Toya-maru accident was made teachings, the watertight door was equipped, and the center of gravity was low designed so that it might be hard to be capsized.
It retired on October 1, 1966, was converted after that, and went into commission as Ishikari-maru II on May 6, 1967.

Tsugaru-maru type ferry
It is the large-sized high-speed connection ship which went into commission on May 10, 1964 for the purpose of replacement of the ship of a war standard ship and Toya-maru type.
The same type ship is 7 boats, Tsugaru-maru II, Hakkoda-maru, Matsumae-maru II, Taisetsu-maru II, Mashu-maru II, Yotei-maru II, and Towada-maru II.
Ships other than Tsugaru-maru II-Matsumae-maru II played an active part as the main force until Seikan ferry was abolished.
The rail of four lines is laid in the vehicle deck, and the 15t boxcar was able to be carried 48 cars.
Between Hakodate was connected in 3 hours and 50 minutes to Aomori.
It was the connection ship which safety measures and laborsaving are attained sharply and is proud of about the same performance as an open sea voyage ship.
In Tsugaru-maru II, sacred fire transportation of Tokyo Olympic Games is performed on September 17, 1964, and Taisetsu-maru II is performing sacred fire transportation of the Sapporo Winter Olympics on February 20, 1972.

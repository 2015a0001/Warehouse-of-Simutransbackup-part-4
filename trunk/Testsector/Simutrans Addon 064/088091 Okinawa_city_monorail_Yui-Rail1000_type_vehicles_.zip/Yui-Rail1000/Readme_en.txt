Okinawa city monorail "Yui-Rail"1000 type vehicles
Copyright(c)HIBARI Mar-05-2006
Document Corrected to Apr-26-2006

Thank you for downloading :-)
This document was translated to the translation site.
I'm sorry when it is hard to read or there is a mistranslation.

*Introduction
Okinawa city monorai was opened on August 10, 2003.
It is the route of 12.9km of operation distance which connects between the Naha airport station in Naha-shi, Okinawa in Japan, and the Shuri stations.
It is the newest monorail in Japan.
"Yui-Rail" of a pet name was connected with "Yuimaaru" which is the custom of the mutual help of Okinawa, and was named.
1000  type vehicles is the vehicles which are playing an active part from the time of commencement of business to the present.
It operates now only in one unit of two-car organization of "11xx(Mc1)-12xx (Mc2)".
When a passenger increases in the future, the same unit is added and it has come be made to four-car organization.

Two vehicles, "Yui-Rail1000Front" (Mc1) and "Yui-Rail1000Rear" (Mc2), are contained in this add-on.
Keep in mind that it is necessary surely connect "Yui-Rail1000Rear" behind "Yui-Rail1000Front", and to construct a unit.

About distribution of this add-on, as long as it is within the limits of the following conditions, you may carry out freely.
1:Don't carry out distribution for the profit purpose.
2:Change no contents and copyright notation of this zip file.
3:Distribute this whole zip file.
However, if Mr. prissi or the development member of simutrans restricts when he puts this add-on into the new version of simutrans, on condition that copyright of a pak file is not changed, you may distribute with a pak file simple substance :-)

Installation only puts each "pak" file into the "pak" folder of Simutrans.
Since operation by versions other than Simutrans 88.04.5 is unidentified, please use it by your accountability.

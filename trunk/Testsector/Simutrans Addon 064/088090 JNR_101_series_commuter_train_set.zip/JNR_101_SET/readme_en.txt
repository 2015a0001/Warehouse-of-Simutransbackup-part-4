JNR 101 series commuter train set
Copyright(c)HIBARI Apr-21-2006

Thank you for downloading :-)
This document was translated to the translation site.
I'm sorry when it is hard to read or there is a mistranslation.


*Introduction

101  series is commuter train of JNR (Japanese National Railways) manufactured from 1957 (a mass-production vehicle is 1958) to 1963.
In Japan, the color of the body was changed according to the route by general train.
It is a train supporting commutation transportation of a Japanese post-war economic miracle term.
It was called the "new performance train" by train which adopted the new technology which was not in the train of JNR till then.

Since he wanted the colorful commuter train, it made.
It made simultaneously with "JNR 103 series commuter train set" and "JNR 201 series commuter train set."

Installation only puts each pak file into the "pak" folder of simutrans.
The check of operation was carried out by the versions 86.03.4, 88.05.1, and 88.08.1 of simutrans.
Although it is making carefully so that it may operate normally, a trouble may arise in operation of simutrans on balance with other add-ons.
Moreover, it may not operate normally by other versions. 
I cannot have responsibility to the possibility of those troubles.
Please judge with responsibility whether this add-on is used.

About distribution of this add-on, as long as it is within the limits of the following conditions, you may carry out freely.
1:Don't carry out distribution for the profit purpose.
2:Change no contents and copyright notation of this zip file.
3:Distribute this whole zip file.

However, if Mr. prissi or the development member of simutrans restricts when he puts this add-on into the new version or pakjapan64 of simutrans, on condition that copyright of a pak file is not changed, you may distribute with a pak file simple substance :-)

It is prohibition to distribute what changed this add-on.
It is prohibition that what has not permitted to change also about all the add-ons that HIBARI exhibited until now distributes the changed add-on.


*The pak file included in this set

The pak file is divided according to the body color.
If the thing of all colors is installed, it will be hard coming to see a garage window.
I consider that it is better to install only the thing of a color to use.

01:vehicle.JNR_101.pak  Player color
02:vehicle.JNR_101o.pak Orange vermilion
03:vehicle.JNR_101k.pak Kanaria yellow (=Canary yellow)
04:vehicle.JNR_101s.pak Sky blue


*A list of an add-on

   intro   retire  add-on name payload weight speed   power gear cost     runningcost
01:1958.03 1963.12 JNR Mc101   136     38t    100km/h 400kw 1.60 13700.00 0.84
02:1958.03 1963.12 JNR Mc100   136     36t    100km/h 400kw 1.60 13000.00 0.79
03:1958.03 1963.12 JNR Tc101   136     30t    100km/h             6700.00 0.41
04:1958.03 1963.12 JNR Tc100   136     30t    100km/h             6700.00 0.41
05:1958.03 1963.12 JNR M101    144     37t    100km/h 400kw 1.60 11100.00 0.67
06:1958.03 1963.12 JNR M100    144     35t    100km/h 400kw 1.60 10400.00 0.63
07:1958.03 1963.12 JNR T101    144     29t    100km/h             4000.00 0.25

As for the thing of Orange vermilion, "o" is attached to the end of add-on name.
As for the thing of Kanaria yellow (=Canary yellow), "k" is attached to the end of add-on name.
As for the thing of Sky blue, "s" is attached to the end of add-on name.

The value of each above-mentioned item is a value set as an add-on.

Only JNR Mc101 and JNR Tc101 are made at the head of a train.
Only JNR Mc100 and JNR Tc100 are made in the tail end.

Connection restriction is carried out so that only JNR Mc100 and JNR M100 cannot be connected behind JNR Mc101 and JNR M101.
Connection restriction is carried out so that only JNR Mc101 and JNR M101 cannot be connected before JNR Mc100 and JNR M100.


*The example of connection

Chuo Line (Orange vermilion)
[JNR Mc101][JNR M100][JNR M101][JNR Mc100][JNR Mc101][JNR M100][JNR M101][JNR M100][JNR M101][JNR Mc100](Trial production train)
[JNR Mc101][JNR M100][JNR Tc100][JNR Mc101][JNR M100][JNR T101][JNR T101][JNR T101][JNR M101][JNR Mc100]
[JNR Tc101][JNR M101][JNR Mc100][JNR Mc101][JNR M100][JNR T101][JNR T101][JNR T101][JNR M101][JNR Mc100]

Yamanote Line (Kanaria yellow=Canary yellow)
[JNR Mc101][JNR M100][JNR T101][JNR T101][JNR M101][JNR M100][JNR M101][JNR Mc100]


*Description about Connection restriction

Usually, on the train (new performance train) in Japan, apparatus required in order that an electric vehicle may move is distributed and carried in two or more vehicles.
Therefore, it cannot run only by one car but it is necessary to surely construct a unit by two or more vehicles.

In the case of the electric vehicle of 101 series, it is one unit in one of the following combination.
[JNR Mc101]-[JNR Mc100]
[JNR Mc101]-[JNR M100 ]
[JNR M101 ]-[JNR M100 ]
[JNR M101 ]-[JNR Mc100]

Moreover, only vehicles with a driver's seat are made into the head and the tail end of organization.


*Introduction of japanese.simutrans.com

Most add-ons which Japanese people made are downloadable from http://www.japanese.simutrans.com/.
The add-on which also made HIBARI is first uploaded to japanese.simutrans.com :-)

NAMC YS-11 BASIC SET
Copyright(c)HIBARI Nov-30-2005
Corrected to Feb-03-2006
Document Corrected to Apr-22-2006

Thank you for downloading! :-)
This document was translated to the translation site.
I'm sorry when it is hard to read or there is a mistranslation.

*Introduction
It is the set of YS-11 made from NAMC (Nihon Aeroplane Manufacturing Co., Ltd.).
YS-11 are the passenger plane which Japan developed and manufactured for the first time after World War II.
Since the forms of wings and engine nacelle were amusing, what was raised to 2005/11/30 was corrected.
Since power was also set up actually more low, it corrected.
Employment of a transition stage until it carries out the increase in passenger demand from the time of air route establishment is recommendation ;-)

It has made from the same scale as Fokker_F27 of Mr. MHz who goes into Simutrans from the start.

About distribution of this add-on, as long as it is within the limits of the following conditions, you may carry out freely.
1:Don't carry out distribution for the profit purpose.
2:Change no contents and copyright notation of this zip file.
3:Distribute this whole zip file.
However, if Mr. prissi or the development member of simutrans restricts when he puts this add-on into the new version of simutrans, on condition that copyright of a pak file is not changed, you may distribute with a pak file simple substance :-)

As long as distribution of the add-on converted and made is within the limits of the following conditions, you may perform it freely.
1:Don't carry out distribution for the profit purpose.
2:Also mix not only a pak file but the png file and dat file which were converted, and distribute them.
3:Specify converting and making the add-on of YS-11 which HIBARI made in readme or a dat file.

Installation only puts each "pak" file into the "pak" folder of Simutrans.
Since operation by versions other than Simutrans 88.01.3 is unidentified, please use it by your accountability.

*The list of an add-on included in this set

   [Intro] [Retire] [Add-on name]    [Capacity]
01:1965.03-1968.03  YS-11-100        64 Passengers
02:1668.03-1972.11  YS-11A-200       64 Passengers
03:1972.11-----.--  YS-11A-500       64 Passengers
04:1969.10-----.--  YS-11A-400_Cargo 24 crates piece goods
05:1969.10-----.--  YS-11A-400_Mail  143 bags Mail

-Introductory years are set up according to the real first delivery years of YS-11.
-What has not filled in retirement-from-service years has not set up retirement-from-service years.
-According to a player color, a body color changes except 05.


*(Reference data)The kind of YS-11

YS-11�FExperimental model
A form top is set to YS-11-100 with the experimental model of YS-11.
Manufacture started in 1961, No. 1 flew in August, 1962 and No. 2 first flew in December of the same year.
No. 1 was used as an object for the development examination of YS-11 to retirement from service.
No. 2 was leased to ALL NIPPON AIRWAYS in September, 1964, performed sacred fire transportation of Tokyo Olympic Games, was leased to JAPAN DOMESTIC AIRLINES after that, and performed passenger transport as a sacred fire number.

YS-11-100�FStandard passenger type
It is a group in early stages of YS-11 familiar mass production.
Since the first stage and the middle type of this group have adopted the heater as the anti ice equipment of wings, the design felt refreshed is the feature.
In order to acquire FAA Type Certification, defrosting boots are adopted from type in the second half.
Maximum cruising speed at 3050m:478km/h
Paylord:5635kg
JCAB Type Certification:1964.08
FAA Type Certification:1965.09
First delivery�F1965.03
1
YS-11A-200�FStandard passenger type
It is a group of the YS-11 family maximum.
It is the body which responded for asking from a foreign airline, improved engine, and increased about 1t of payloads compared with -100.
All the groups after this group have adopted defrosting boots.
Maximum cruising speed at 3050m:472km/h
Paylord:6581kg
JCAB Type Certification:1968.01
FAA Type Certification:1968.04
First delivery�F1968.03

YS-11A-300�FFreight passenger mixed-loading type
The cargo door is attached to body front left-hand side into the group which used -200 as the freight passenger mixed-loading type.
Although basic performance is the same as that of -200, compared with -200, the payload is decreasing for the increase in prudence by change of body structure.
Maximum cruising speed at 3050m:472km/h
Paylord:6131kg
JCAB Type Certification:1968.07
FAA Type Certification:1968.08
First delivery�F1968.07

YS-11A-400�FCargo type
The cargo door is attached to body back left-hand side into the group which used -200 as the cargo type.
This group does not have an introductory track record to an airline, and is employed only by JASDF and JMSDF.
Although fundamentality ability is the same as that of -200, compared with -200, the payload is increasing for reduction of prudence by change of body structure.
Maximum cruising speed at 3050m:472km/h
Paylord:7165kg
First delivery�F1969.10

YS-11A-500�FStandard passenger type
It is the group which improved engine further from -200 and increased about 0.5t of payloads compared with -200.
There is little body by which the product made from new was carried out, and most is occupied with the reconstruction machine from -200.
Maximum cruising speed at 3050m:470m/h
Paylord:7038kg
JCAB Type Certification:1970.04
FAA Type Certification:1970.05
First delivery�F1972.11

YS-11A-600�FFreight passenger mixed-loading type
It is the group which improved the engine of -300 like -500 and increased about 0.5t of payloads compared with -300.
There is little body by which the product made from new was carried out, and most is occupied with the reconstruction machine from -300.
Maximum cruising speed at 3050m:470km/h
Paylord:6631kg
JCAB Type Certification:1970.04
FAA Type Certification:1970.05

-JCAB=Japan Civil Aviation Bureau
-FAA=U.S. Federal Aviation Administration
-JASDF=Japan Air Self Defense Force
-JMSDF=Japan Maritime Self Defense Force

-Furthermore, a fine kind
 YS-11A-500R:The model which changed engine for "Rolls Royce Dart Mk542-10" "Dart Mk543" series from series.
 Super YS-11(Common name):The model which changed the engine of YS-11 for JASDF for "T64-IHI-10J."

-"(Reference data) Chronology of YS-11" is in readme of "NAMC YS-11 JAPANESE AIRLINE SET".

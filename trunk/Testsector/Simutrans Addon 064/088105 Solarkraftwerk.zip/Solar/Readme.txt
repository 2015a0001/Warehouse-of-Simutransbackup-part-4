This is an add-on for pak64.
This add-on is a solar panel.
This add-on is made by MH35.
You can distribute it.
JNR 103 series commuter train set
Copyright(c)HIBARI Apr-21-2006

Thank you for downloading :-)
This document was translated to the translation site.
I'm sorry when it is hard to read or there is a mistranslation.


*Introduction

103 series is commuter train of JNR (Japanese National Railways) manufactured from 1963 (a mass-production vehicle is 1964) to 1984.
In Japan, the color of the body was changed according to the route by general train.
It is the train which supported commutation transportation of a Japanese post-war economic miracle term with 101 series. 
The output and gear ratio of a motor were raised and it was developed as a "standard commutation type train" which can run by the low running cost rather than 101 series by reducing the rate of the electric car included in one train.
3447 cars were manufactured in the form of the maximum in the possession vehicles of JNR.

Since he wanted the colorful commuter train, it made.
It made simultaneously with "JNR 101 series commuter train set" and "JNR 201 series commuter train set."
What has nothing air conditioning, and a thing with air conditioning were prepared.

Installation only puts each pak file into the "pak" folder of simutrans.
The check of operation was carried out by the versions 86.03.4, 88.05.1, and 88.08.1 of simutrans.
Although it is making carefully so that it may operate normally, a trouble may arise in operation of simutrans on balance with other add-ons.
Moreover, it may not operate normally by other versions.
I cannot have responsibility to the possibility of those troubles.
Please judge with responsibility whether this add-on is used.

About distribution of this add-on, as long as it is within the limits of the following conditions, you may carry out freely.
1:Don't carry out distribution for the profit purpose.
2:Change no contents and copyright notation of this zip file.
3:Distribute this whole zip file.

However, if Mr. prissi or the development member of simutrans restricts when he puts this add-on into the new version or pakjapan64 of simutrans, on condition that copyright of a pak file is not changed, you may distribute with a pak file simple substance :-)

It is prohibition to distribute what changed this add-on.
It is prohibition that what has not permitted to change also about all the add-ons that HIBARI exhibited until now distributes the changed add-on.


*The pak file included in this set

The pak file is divided according to the body color.
If the thing of all colors is installed, it will be hard coming to see a garage window.
I consider that it is better to install only the thing of a color to use.

(With no air conditioning)
01:vehicle.JNR_103.pak   Player color
02:vehicle.JNR_103u.pak  Uguisu green (=Japanese Bush Warbler green)
03:vehicle.JNR_103s.pak  Sky blue
04:vehicle.JNR_103e.pak  Emerald green
05:vehicle.JNR_103o.pak  Orange vermilion
06:vehicle.JNR_103k.pak  Kanaria yellow (=Canary yellow)

(Those with air conditioning)
07:vehicle.JNR_103c.pak  Player color
08:vehicle.JNR_103uc.pak Uguisu green (=Japanese Bush Warbler green)
09:vehicle.JNR_103sc.pak Sky blue
10:vehicle.JNR_103ec.pak Emerald green
11:vehicle.JNR_103oc.pak Orange vermilion
12:vehicle.JNR_103kc.pak Kanaria yellow (=Canary yellow)


*A list of an add-on

(With no air conditioning)
   intro   retire  add-on name   payload weight speed   power gear cost     runningcost
01:1963.12 1973.01 JNR Mc103     136     38t    100km/h 440kw 1.73 13500.00 0.88
02:1963.12 1973.01 JNR Tc103(A)  136     27t    100km/h             6700.00 0.44
03:1963.12 1973.01 JNR Tc103(B)  136     27t    100km/h             6700.00 0.44
04:1963.12 1973.01 JNR M103      144     37t    100km/h 440kw 1.73 11000.00 0.73
05:1963.12 1973.01 JNR M'102     144     35t    100km/h 440kw 1.73 10500.00 0.69
06:1963.12 1973.01 JNR T103      144     26t    100km/h             4000.00 0.26

(Those with air conditioning)
   intro   retire  add-on name   payload weight speed   power gear cost     runningcost
07:1973.01 1984.02 JNR Mc103c    136     40t    100km/h 440kw 1.73 14200.00 0.93
08:1973.01 1984.02 JNR Tc103(A)c 136     31t    100km/h             7700.00 0.51
09:1973.01 1984.02 JNR Tc103(B)c 136     31t    100km/h             7700.00 0.51
10:1973.01 1984.02 JNR M103c     144     40t    100km/h 440kw 1.73 11900.00 0.79
11:1973.01 1984.02 JNR M'102c    144     40t    100km/h 440kw 1.73 12000.00 0.79
12:1973.01 1984.02 JNR T103c     144     29t    100km/h             4500.00 0.29
13:1974.02 1984.02 JNR Tc103H(A) 136     31t    100km/h             7700.00 0.51
14:1974.02 1984.02 JNR Tc103H(B) 136     31t    100km/h             7700.00 0.51

That to which (A) is attached to add-on name is a lead coach.
It is the rear vehicle which (B) attaches to add-on name.

That to which "H" is attached to add-on name is the vehicles with which the window of a cab sticks to the high position.

As for the thing of Uguisu green (=Japanese Bush Warbler green), "u" is attached to the end of add-on name.
As for the thing of Sky blue, "s" is attached to the end of add-on name.
As for the thing of Emerald green, "e" is attached to the end of add-on name.
As for the thing of Orange vermilion, "o" is attached to the end of add-on name.
As for the thing of Kanaria yellow (=Canary yellow), "k" is attached to the end of add-on name.

The value of each above-mentioned item is a value set as an add-on.
However, since the thing of Uguisu green (=Japanese Bush Warbler green) and the thing of Sky blue are made from JNR Tc103H(A) and JNR Tc103H(B) with the intention of an ATC loading vehicle, it has been set as the weight of 33t, the vehicles price 8200.00, and operation cost 0.54.

Being made at the head of a train is only the five following kinds.
JNR Mc103
JNR Mc103c
JNR Tc103(A)
JNR Tc103(A)c
JNR Tc103H(A)

Being made in the tail end is only the three following kinds.
JNR Tc103(B)
JNR Tc103(B)c
JNR Tc103H(B)

Connection restriction is carried out so that only JNR M'102 and JNR M'102c can be connected behind JNR Mc103, JNR Mc103 c, JNR M103, and JNR M103c.
Connection restriction is carried out so that only JNR Mc103, JNR Mc103 c, JNR M103, and JNR M103c can be connected before JNR M'102 and JNR M'102c.


*The example of connection

Yamanote Line (Uguisu green=Japanese Bush Warbler green)
[JNR Tc103(A)][JNR M103][JNR M'102][JNR Tc103(B)][JNR Tc103(A)][JNR M103][JNR M'102][JNR Tc103(B)](Trial production train)
[JNR Tc103(A)][JNR M103][JNR M'102][JNR T103][JNR T103][JNR M103][JNR M'102][JNR Tc103(B)]
[JNR Tc103(A)][JNR M103][JNR M'102][JNR T103][JNR M103][JNR M'102][JNR T103][JNR M103][JNR M'102][JNR Tc103(B)]

Keihin-Tohoku Line (Sky blue)
[JNR Mc103][JNR M'102][JNR Tc103(B)][JNR Mc103][JNR M'102][JNR T103][JNR T103][JNR M103][JNR M'102][JNR Tc103(B)]


*Description about organization restrictions

Usually, on the train (new performance train) in Japan, apparatus required in order that an electric vehicle may move is distributed and carried in two or more vehicles.
Therefore, it cannot run only by one car but it is necessary to surely construct a unit by two or more vehicles.

In the case of the electric vehicle of 103 series, it is one unit in one of the following combination.
[JNR Mc103 ]�\[JNR M'102 ]
[JNR Mc103c]�\[JNR M'102c]
[JNR Mc103 ]�\[JNR M'102 ]
[JNR Mc103c]�\[JNR M'102c]

Moreover, only vehicles with a driver's seat are made into the head and the tail end of organization.


*Introduction of japanese.simutrans.com

Most add-ons which Japanese people made are downloadable from http://www.japanese.simutrans.com/.
The add-on which also made HIBARI is first uploaded to japanese.simutrans.com :-)

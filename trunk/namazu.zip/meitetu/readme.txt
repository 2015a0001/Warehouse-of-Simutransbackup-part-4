Thank you for downloading set of Meitetsu 850 series.

-how to use-
 Put pak files in pak128.japan folder.
If you remodel addons, Use files in source folder.
There are ja.tab & en.tab in text folder under pak128.japan folder.
Use these that add in the same tab files.

-right-
 This copyright is owned by koa. 
You may remodel source file. And you may distribute there when you use there with simutrans and
other softwares(Commerce is available).

-history-
06/28/2015 release
03/31/2016 3400 series are added
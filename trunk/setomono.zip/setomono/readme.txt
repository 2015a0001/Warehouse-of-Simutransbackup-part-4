Thank you for downloading set of pottery industry chain.

-contents-
-factory.pottery_studio.pak.pak		:addon
-factory.supermarket.pak		:addon
-good.pottery.pak			:addon
-tokoname.png				:source(image)
-tilecut_tokoname.png			:source(image)
-tokoname_s.png				:source(image)
-tilecut_tokoname_s.png			:source(image)
-supermarket.png			:source(image)
-goods.dat				:source(setting)
-pottery.dat				:source(setting)
-supermarket.dat			:source(setting)
-ja.tab				:document that translated train name into Japanese
-���ł�.txt			:document that translated "readme.txt" into Japanese
 readme.txt				:this
-how to use-
 Put pak files in pak128.japan folder.
Use attached dat & png files if you remodel addons.
There are ja.tab & en.tab in text folder under pak128.japan folder.
Use these that add in the same tab files.

-attention-
This addon changes property of supermarket addon.
I take no responsibility in regards to troubles.
I recommend to take backup of supermarket addon.

-right-
 You are permitted to remodel and to distribute remodeled,
 because this addon files attach source file(except supermarket.png and supermarket.pak).
 You are permitted to port softwares other than simutrans(except supermarket.png and supermarket.pak).
 Write that files are remodeled when you distribute remodeled.

-history-
09/04/2014 release